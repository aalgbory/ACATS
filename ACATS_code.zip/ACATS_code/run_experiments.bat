@echo off
REM Comparison on fresh seeds (run from the "code" folder: cd code, then ..\run_experiments.bat).
REM 4 methods x 3 seeds x 2 datasets = 24 runs, about 2-3 hours on a Core i5.
for %%D in (ton_iot ciciot2023) do (
  for %%S in (101 202 303) do (
    python -m framework.run_acats --dataset %%D --profile laptop --seed %%S
    python -m framework.run_acats --dataset %%D --profile laptop --seed %%S --final best --sizew 0.10
    python -m reproduction.cats_fixed --dataset %%D --profile laptop --seed %%S --output best
    python -m reproduction.cats_fixed --dataset %%D --profile laptop --seed %%S --output onese
  )
  python -m tools.compare_seeds --dataset %%D --profile laptop --seeds 101 202 303
)
