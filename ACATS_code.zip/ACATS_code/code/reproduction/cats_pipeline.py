"""Faithful reproduction of CAT-S (Nazir et al., 2023)."""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from common.config import CATS, PROFILES, RANDOM_STATE, RESULTS_DIR
from common.data import load_dataset, stratified_cap
from common.evaluator import FitnessEvaluator, rf_factory
from common.metrics import all_metrics, nazir_cost, per_class_f1
from common.nested import _plot_convergence, make_holdout_split
from common.utils import Timer, ensure_utf8_stdout, log, mean_std, save_json

from .cats_core import cats_search


def _score(model_factory, X, y, tr, te, mask, normal):
    cols = np.flatnonzero(mask)
    m = model_factory()
    m.fit(X[np.ix_(tr, cols)], y[tr])
    pred = m.predict(X[np.ix_(te, cols)])
    met = all_metrics(y[te], pred, normal)
    met["cost_nazir"] = nazir_cost(met["accuracy"], int(mask.sum()), met["weighted_fpr"])
    return met, pred


def run(dataset: str, profile: str, runs: int | None = None, seed: int = RANDOM_STATE,
        keep_id: bool = True, neighbours: str = "generations", boundary: str = "ring",
        tabu_store: str = "solution", iterations: int | None = None, tag: str | None = None) -> dict:
    a = argparse.Namespace(dataset=dataset, profile=profile, runs=runs, seed=seed)
    params = dict(CATS, neighbours=neighbours, boundary=boundary, tabu_store=tabu_store)
    variant = dict(neighbours=neighbours, boundary=boundary, tabu_store=tabu_store)
    default_variant = variant == dict(neighbours="generations", boundary="ring",
                                      tabu_store="solution")
    prof = PROFILES[a.profile]
    runs = a.runs or prof["runs"]
    n_iter = iterations or prof["iterations"]
    Xdf, y, meta = load_dataset(a.dataset, prof, keep_identity=keep_id, seed=a.seed)
    X = Xdf.to_numpy(dtype=np.float32)
    feats = np.array(meta["features"])
    normal = meta["normal"]
    D = X.shape[1]
    vtag = tag or ("" if default_variant else f"_{neighbours}_{boundary}_{tabu_store}")
    out = RESULTS_DIR / a.dataset / (f"cats_faithful_{a.profile}_{'keepid' if keep_id else 'noid'}"
                                     f"{vtag}_s{a.seed}")
    out.mkdir(parents=True, exist_ok=True)
    log(f"=== CAT-S faithful | {a.dataset} | {X.shape[0]} rows x {D} features | {runs} runs | "
        f"identity {'KEPT' if keep_id else 'dropped'} | {n_iter} iterations | {variant} ===")

    rows, masks, histories = [], [], {}
    pooled_true, pooled_pred = [], []
    for r in range(runs):
        rng = np.random.default_rng(a.seed + r)
        (pool, hold), = make_holdout_split(y, 0.2, a.seed + r)
        n_cls = len(np.unique(y))
        s_idx = pool[stratified_cap(y[pool], prof["search_rows"],
                                    max(10, prof["search_rows"] // (3 * n_cls)), rng)]
        (s_tr, s_te), = make_holdout_split(y[s_idx], 0.3, a.seed + r)
        Xs, ys = X[s_idx], y[s_idx]
        ev = FitnessEvaluator(Xs, ys, normal, [(s_tr, s_te)],
                              rf_factory(prof["trees_search"], a.seed + r),
                              kind="nazir", weights=CATS["weights"])
        with Timer() as t:
            res = cats_search(ev, D, n_iter, prof["n_neighbors"], params, rng)
        mask = res["mask"]
        masks.append(mask)
        final = rf_factory(prof["trees_final"], a.seed + r)
        train_rows = s_idx[s_tr]
        paper, _ = _score(final, Xs, ys, s_tr, s_te, mask, normal)
        hold_m, pred = _score(final, X, y, train_rows, hold, mask, normal)
        seen_m, _ = _score(final, X, y, train_rows, hold, res["best_seen_mask"], normal)
        allm = np.ones(D, dtype=bool)
        all_paper, _ = _score(final, Xs, ys, s_tr, s_te, allm, normal)
        all_hold, _ = _score(final, X, y, train_rows, hold, allm, normal)
        pooled_true.append(y[hold])
        pooled_pred.append(pred)
        row = dict(run=r, n_selected=int(mask.sum()), search_seconds=round(t.seconds, 1),
                   skipped_iterations=res["skipped"], aspirations=res["aspirations"],
                   moves=res["n_moves"], mean_bits_changed_per_move=round(res["mean_move_hamming"], 2),
                   final_cost=res["final_f"], best_seen_cost=res["best_seen_f"],
                   best_seen_n=int(res["best_seen_mask"].sum()), **ev.stats())
        row.update({f"paper_{k}": v for k, v in paper.items()})
        row.update({f"holdout_{k}": v for k, v in hold_m.items()})
        row.update({f"bestseen_holdout_{k}": v for k, v in seen_m.items()})
        row.update({f"allfeat_paper_{k}": v for k, v in all_paper.items()})
        row.update({f"allfeat_holdout_{k}": v for k, v in all_hold.items()})
        rows.append(row)
        h = pd.DataFrame(res["history"])
        h.to_csv(out / f"history_run{r}.csv", index=False)
        histories[r] = h
        log(f"[run {r + 1}/{runs}] n={mask.sum()}  paper-style Acc={paper['accuracy']:.4f}  "
            f"holdout Acc={hold_m['accuracy']:.4f} MacroF1={hold_m['macro_f1']:.4f}  "
            f"all-features Acc={all_paper['accuracy']:.4f}/{all_hold['accuracy']:.4f}  "
            f"skipped={res['skipped']}  aspirations={res['aspirations']}  {t.seconds:.0f}s")

    df = pd.DataFrame(rows)
    df.to_csv(out / "runs.csv", index=False)
    M = np.vstack(masks)
    freq = pd.DataFrame({"feature": feats, "selected_in_runs": M.sum(0), "frequency": M.mean(0)})
    freq.sort_values(["frequency", "feature"], ascending=[False, True]).to_csv(
        out / "feature_frequency.csv", index=False)
    pd.Series(per_class_f1(np.concatenate(pooled_true), np.concatenate(pooled_pred))).to_csv(
        out / "per_class_f1_holdout.csv", header=["f1"])
    cols = ["accuracy", "macro_f1", "fpr", "weighted_fpr", "cost_nazir"]
    summary = dict(
        method="cats_faithful", dataset=a.dataset, profile=a.profile, runs=runs,
        identity="kept" if keep_id else "dropped", n_features_total=D,
        n_selected=mean_std(df["n_selected"]),
        paper_style={c: mean_std(df[f"paper_{c}"]) for c in cols},
        holdout={c: mean_std(df[f"holdout_{c}"]) for c in cols},
        best_seen_holdout={c: mean_std(df[f"bestseen_holdout_{c}"]) for c in cols},
        all_features_paper_style={c: mean_std(df[f"allfeat_paper_{c}"]) for c in cols},
        all_features_holdout={c: mean_std(df[f"allfeat_holdout_{c}"]) for c in cols},
        rows_used=int(X.shape[0]), search_rows=int(prof["search_rows"]),
        iterations=n_iter, trees_search=prof["trees_search"], trees_final=prof["trees_final"],
        variant=variant,
        skipped_iterations=mean_std(df["skipped_iterations"]),
        aspirations_total=int(df["aspirations"].sum()),
        mean_bits_changed_per_move=mean_std(df["mean_bits_changed_per_move"]),
        search_seconds=mean_std(df["search_seconds"]),
        cats_params=params,
        note="output = current solution after the last iteration (as in the paper)")
    save_json(summary, out / "summary.json")
    save_json(meta, out / "data_meta.json")
    _plot_convergence(histories, out / "convergence.png", f"CAT-S faithful on {a.dataset}")

    log(f"--- CAT-S faithful on {a.dataset}: |S| = {summary['n_selected']} of {D}")
    log(f"    paper-style  Acc {summary['paper_style']['accuracy']}  "
        f"MacroF1 {summary['paper_style']['macro_f1']}  cost {summary['paper_style']['cost_nazir']}")
    log(f"    holdout      Acc {summary['holdout']['accuracy']}  "
        f"MacroF1 {summary['holdout']['macro_f1']}  FPR {summary['holdout']['fpr']}")
    log(f"    all features paper-style Acc {summary['all_features_paper_style']['accuracy']}  "
        f"holdout Acc {summary['all_features_holdout']['accuracy']}")
    log(f"    aspiration accepted {summary['aspirations_total']} times; "
        f"bits changed per move {summary['mean_bits_changed_per_move']}")
    log(f"Results saved in {out}")
    summary["_dir"] = str(out)
    return summary


def main():
    ensure_utf8_stdout()
    p = argparse.ArgumentParser(description="CAT-S faithful reproduction")
    p.add_argument("--dataset", default="ton_iot")
    p.add_argument("--profile", default="quick", choices=list(PROFILES))
    p.add_argument("--runs", type=int, default=None, help="default: profile value")
    p.add_argument("--iterations", type=int, default=None, help="default: profile value")
    p.add_argument("--seed", type=int, default=RANDOM_STATE)
    p.add_argument("--drop-identity", action="store_true")
    p.add_argument("--neighbours", choices=["generations", "perturbed"], default="generations")
    p.add_argument("--boundary", choices=["ring", "null"], default="ring")
    p.add_argument("--tabu-store", choices=["solution", "move"], default="solution")
    a = p.parse_args()
    run(a.dataset, a.profile, a.runs, a.seed, not a.drop_identity, a.neighbours, a.boundary,
        a.tabu_store, a.iterations)


if __name__ == "__main__":
    main()
