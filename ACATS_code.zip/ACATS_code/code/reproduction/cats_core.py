"""CAT-S search loop as described by Nazir et al. (2023), Sections 3.5 and 5, Fig. 3.

Followed literally:
  * random initial bit vector, one bit per feature, in the dataset's column order
  * 5 neighbours per iteration from CA Rule 30
  * the neighbour with the lowest cost is the "neighbour best"
  * Tabu List = last 7 accepted solutions (FIFO)
  * if the neighbour best is tabu, it is accepted only if cost < aspiration level (0.02);
    otherwise the iteration ends without a move (Fig. 3: "NO" goes to the stopping test)
  * the accepted neighbour replaces the current solution even if it is worse
  * stop after 100 iterations; the output is the CURRENT solution (no best-so-far memory)

Not specified in the paper (our documented choices):
  * how 5 different neighbours come from one deterministic rule
        neighbours='generations' (default) : generations 1..5 of the rule
        neighbours='perturbed'             : one rule step from 5 one-bit perturbations
  * boundary condition: 'ring' (default) or 'null'
  * what is stored in the Tabu List ("that move is held in the Tabu List", Sec. 5.5)
        tabu_store='solution' (default)    : the accepted solution vector
        tabu_store='move'                  : the set of bits the move flipped
  tools.cats_sensitivity runs every combination and reports the range.
We also record the best solution ever seen, for analysis only.
"""
from __future__ import annotations

from collections import deque

import numpy as np

from framework.ca_rules import cats_neighbours


def cats_search(evaluator, D: int, iterations: int, n_neighbors: int, params: dict,
                rng: np.random.Generator, output: str = "current") -> dict:
    z = (rng.random(D) < 0.5).astype(np.uint8)
    if z.sum() == 0:
        z[rng.integers(D)] = 1
    cur_f, cur_info = evaluator(z.astype(bool))
    seen_z, seen_f, seen_info = z.copy(), cur_f, cur_info
    tabu: deque[bytes] = deque(maxlen=params["tabu_size"])

    history, skipped, aspirations, hamming = [], 0, 0, []
    for it in range(1, iterations + 1):
        nbs = cats_neighbours(z, n_neighbors, params["rule"], params["boundary"], rng,
                              params.get("neighbours", "generations"))
        scored = []
        for nb in nbs:
            f, info = evaluator(nb.astype(bool))
            scored.append((f, nb, info))
        f, nb, info = min(scored, key=lambda s: s[0])
        if params.get("tabu_store", "solution") == "move":
            key = np.packbits(nb != z).tobytes()
        else:
            key = evaluator.key(nb.astype(bool))

        if key in tabu and not f < params["aspiration"]:
            how = "skipped"
            skipped += 1
        else:
            how = "aspiration" if key in tabu else "free"
            aspirations += how == "aspiration"
            hamming.append(int((nb != z).sum()))
            z, cur_f, cur_info = nb.copy(), f, info
            tabu.append(key)
            if f < seen_f:
                seen_z, seen_f, seen_info = z.copy(), f, info

        history.append(dict(iteration=it, accepted=how, current_f=round(cur_f, 6),
                            best_f=round(seen_f, 6), current_n=int(z.sum()),
                            current_acc=cur_info.get("accuracy"),
                            current_macro_f1=cur_info.get("macro_f1")))

    final = z if output == "current" else seen_z
    return dict(mask=final.astype(bool), final_f=cur_f, final_info=cur_info,
                best_seen_mask=seen_z.astype(bool), best_seen_f=seen_f, best_seen_info=seen_info,
                history=history, skipped=skipped, aspirations=aspirations,
                mean_move_hamming=float(np.mean(hamming)) if hamming else 0.0,
                n_moves=len(hamming))
