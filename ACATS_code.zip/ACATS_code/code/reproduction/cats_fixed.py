"""CAT-S with the EVALUATION fixed, the ALGORITHM unchanged."""
from __future__ import annotations

import argparse

from common.config import ACATS, CATS, RANDOM_STATE
from common.evaluator import FitnessEvaluator, rf_factory
from common.nested import make_inner_splits, run_nested
from common.utils import ensure_utf8_stdout

from .cats_core import cats_search


def make_search_fn(output="current", weights=None):
    weights = weights or ACATS["weights"]

    def search_fn(Xs, ys, ctx):
        prof = ctx["profile"]
        splits = make_inner_splits(ys, prof["inner_folds"], ctx["seed"])
        ev = FitnessEvaluator(Xs, ys, ctx["normal"], splits,
                              rf_factory(prof["trees_search"], ctx["seed"]),
                              kind="normalized", weights=weights)
        res = cats_search(ev, Xs.shape[1], prof["iterations"], prof["n_neighbors"], CATS,
                          ctx["rng"], output="best" if output == "onese" else output)
        sel_info = {}
        if output == "onese":
            from framework.lattice import discretize, nmi_matrix
            from framework.selection import one_se_select
            W = nmi_matrix(discretize(Xs, ACATS["mi_bins"], ACATS["discretization"]))
            res["mask"], sel_info = one_se_select(ev, W)
        info = dict(final_fitness=res["final_f"], best_seen_fitness=res["best_seen_f"],
                    skipped=res["skipped"], aspirations=res["aspirations"],
                    bits_changed_per_move=round(res["mean_move_hamming"], 2), **ev.stats(),
                    **{f"final_{k}": v for k, v in sel_info.items()})
        return dict(mask=res["mask"], history=res["history"], info=info)
    return search_fn


def main():
    ensure_utf8_stdout()
    p = argparse.ArgumentParser(description="CAT-S with corrected evaluation")
    p.add_argument("--dataset", default="synthetic")
    p.add_argument("--profile", default="quick", choices=["quick", "laptop", "full", "paper"])
    p.add_argument("--seed", type=int, default=RANDOM_STATE)
    p.add_argument("--output", choices=["current", "best", "onese"], default="current",
                   help="'current' = as the paper; 'best' = best solution seen; "
                        "'onese' = the ACATS final selection (search size weight 0.02)")
    a = p.parse_args()
    name = {"current": "cats_fixed", "best": "cats_fixed_bestseen",
            "onese": "cats_fixed_onese"}[a.output]
    w = (0.93, 0.02, 0.05) if a.output == "onese" else ACATS["weights"]
    run_nested(a.dataset, a.profile, name, make_search_fn(a.output, w), seed=a.seed,
               extra_meta=dict(cats_params=CATS, weights=list(w), output=a.output))


if __name__ == "__main__":
    main()
