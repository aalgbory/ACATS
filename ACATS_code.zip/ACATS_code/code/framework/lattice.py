"""Correlation-ordered feature lattice (the original component of ACATS).

1. Discretise each feature into quantile bins (on the outer-train search sample only).
2. W[i, j] = normalised mutual information NMI(f_i ; f_j) = I / sqrt(H_i H_j).
3. Normalised graph Laplacian L_sym = I - D^-1/2 W D^-1/2  (L = D - W available).
4. Fiedler vector = D^-1/2 x eigenvector of the 2nd-smallest eigenvalue of L_sym.
5. Sorting the features by their Fiedler value (spectral seriation, Atkins et al. 1998)
   places strongly dependent features next to each other, so the left / right
   neighbours of a CA cell are related features instead of arbitrary ones.

The lattice is LINEAR (null boundary): the two ends of a Fiedler ordering are the
least similar features, so closing it into a ring would join them.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def discretize(X: np.ndarray, bins: int = 16, method: str = "adaptive") -> np.ndarray:
    """Turn every feature into integer codes for the MI computation.

    method='adaptive' (default):
      * <= bins distinct values -> one code per value (categorical / flags / encoded text)
      * otherwise the most frequent value gets its own code (IoT features are often 95 %+
        zeros or '-'), and the remaining values are cut into quantile bins
    method='quantile': plain quantile bins (first version). Sparse features then collapse
      into ONE bin, have zero entropy and zero NMI with everything, so their place on the
      lattice is arbitrary (seen on TON_IoT: 21 of 38 features)."""
    X = np.asarray(X, dtype=np.float64)
    out = np.empty(X.shape, dtype=np.int32)
    qs = np.linspace(0, 1, bins + 1)[1:-1]
    for j in range(X.shape[1]):
        x = X[:, j]
        if method == "quantile":
            edges = np.unique(np.quantile(x, qs))
            out[:, j] = np.searchsorted(edges, x, side="right")
            continue
        vals, inv, cnt = np.unique(x, return_inverse=True, return_counts=True)
        if len(vals) <= bins:
            out[:, j] = inv
            continue
        mode = vals[np.argmax(cnt)]
        rest = x != mode
        codes = np.zeros(len(x), dtype=np.int32)
        edges = np.unique(np.quantile(x[rest], np.linspace(0, 1, bins)[1:-1]))
        codes[rest] = 1 + np.searchsorted(edges, x[rest], side="right")
        out[:, j] = codes
    return out


def _entropy(counts: np.ndarray) -> float:
    p = counts[counts > 0] / counts.sum()
    return float(-(p * np.log(p)).sum())


def _mi(a: np.ndarray, b: np.ndarray, ka: int, kb: int) -> tuple[float, float, float]:
    joint = np.bincount(a * kb + b, minlength=ka * kb).astype(np.float64)
    ha = _entropy(np.bincount(a, minlength=ka).astype(np.float64))
    hb = _entropy(np.bincount(b, minlength=kb).astype(np.float64))
    hab = _entropy(joint)
    return ha + hb - hab, ha, hb


def nmi_matrix(Xd: np.ndarray) -> np.ndarray:
    D = Xd.shape[1]
    k = Xd.max(axis=0) + 1
    W = np.zeros((D, D))
    for i in range(D):
        for j in range(i + 1, D):
            mi, hi, hj = _mi(Xd[:, i], Xd[:, j], int(k[i]), int(k[j]))
            v = mi / np.sqrt(hi * hj) if hi > 0 and hj > 0 else 0.0
            W[i, j] = W[j, i] = max(v, 0.0)
    return W


def mi_with_target(Xd: np.ndarray, y) -> np.ndarray:
    """I(f_j ; y) on the discretised features (used by the Dey filter baseline)."""
    codes, _ = pd.factorize(np.asarray(y))
    ky = codes.max() + 1
    return np.array([_mi(Xd[:, j], codes, int(Xd[:, j].max() + 1), int(ky))[0]
                     for j in range(Xd.shape[1])])


def fiedler_order(W: np.ndarray, laplacian: str = "normalized") -> tuple[np.ndarray, dict]:
    """laplacian='normalized'  : L_sym = I - D^-1/2 W D^-1/2, Fiedler = D^-1/2 u2  (default)
       laplacian='unnormalized': L = D - W (as in the first design diagram).
    On feature graphs the unnormalised version is dominated by weakly connected (noise)
    features and gives neighbourhoods barely better than random; the normalised one
    keeps related features together (see `coherence` in the lattice output)."""
    D = W.shape[0]
    Wc = W + 1e-9 * (1 - np.eye(D))            # keep the graph connected
    deg = Wc.sum(1)
    if laplacian == "normalized":
        Dm = np.diag(1.0 / np.sqrt(deg))
        vals, vecs = np.linalg.eigh(np.eye(D) - Dm @ Wc @ Dm)
        v = Dm @ vecs[:, 1]
    else:
        vals, vecs = np.linalg.eigh(np.diag(deg) - Wc)
        v = vecs[:, 1]
    if v[np.argmax(np.abs(v))] < 0:            # sign is arbitrary; fix it for reproducibility
        v = -v
    order = np.argsort(v, kind="stable")
    return order, dict(algebraic_connectivity=float(vals[1]), fiedler=v)


def adjacent_coherence(W: np.ndarray, order: np.ndarray, ring: bool = False) -> float:
    """Mean NMI between lattice neighbours (higher = more meaningful neighbourhoods)."""
    a = W[order[:-1], order[1:]]
    if ring:
        a = np.append(a, W[order[-1], order[0]])
    return float(a.mean())


def build_lattice(X: np.ndarray, feature_names, mode: str = "spectral", bins: int = 16,
                  rng: np.random.Generator | None = None,
                  laplacian: str = "normalized",
                  discretization: str = "adaptive") -> tuple[np.ndarray, pd.DataFrame, dict]:
    """Return (order, table, info). order[p] = column index placed at lattice cell p.
    mode: 'spectral' (ACATS) | 'spectral-unnorm' | 'random' (ablation) | 'identity' (dataset column order, as CAT-S)."""
    rng = rng or np.random.default_rng()
    D = X.shape[1]
    W = nmi_matrix(discretize(X, bins, discretization))
    info = {}
    if mode == "spectral":
        order, info = fiedler_order(W, laplacian)
    elif mode == "spectral-unnorm":
        order, info = fiedler_order(W, "unnormalized")
    elif mode == "random":
        order = rng.permutation(D)
    elif mode == "identity":
        order = np.arange(D)
    else:
        raise ValueError(mode)
    rand = np.mean([adjacent_coherence(W, rng.permutation(D)) for _ in range(200)])
    info.update(isolated_features=int((W.max(1) < 1e-6).sum()),
                coherence=adjacent_coherence(W, order), coherence_random_mean=float(rand),
                coherence_identity=adjacent_coherence(W, np.arange(D)))
    names = np.asarray(feature_names)
    left = [W[order[p], order[p - 1]] if p > 0 else np.nan for p in range(D)]
    right = [W[order[p], order[p + 1]] if p < D - 1 else np.nan for p in range(D)]
    table = pd.DataFrame({
        "cell": np.arange(D), "feature": names[order],
        "left_neighbour": [names[order[p - 1]] if p > 0 else "" for p in range(D)],
        "right_neighbour": [names[order[p + 1]] if p < D - 1 else "" for p in range(D)],
        "nmi_left": np.round(left, 4), "nmi_right": np.round(right, 4),
        "fiedler": np.round(info["fiedler"][order], 6) if "fiedler" in info else np.nan,
    })
    info.pop("fiedler", None)
    info["_W"] = W
    return order, table, info
