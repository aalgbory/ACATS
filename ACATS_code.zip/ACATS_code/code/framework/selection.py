"""Final-subset selection that uses the measured noise of the fitness (ACATS)."""
from __future__ import annotations

import numpy as np


def _unpack(key: bytes, D: int) -> np.ndarray:
    return np.unpackbits(np.frombuffer(key, np.uint8))[:D].astype(bool)


def one_se_select(evaluator, W: np.ndarray | None, tau_floor: float = 0.002,
                  trim: bool = True) -> tuple[np.ndarray, dict]:
    D = evaluator.D
    arch = [(info["macro_f1"], info.get("fold_f1", []), k)
            for k, (f, info) in evaluator.cache.items()
            if np.isfinite(f) and "macro_f1" in info]
    f1_best, folds_best, _ = max(arch, key=lambda a: a[0])
    k = len(folds_best)
    se = float(np.std(folds_best, ddof=1) / np.sqrt(k)) if k > 1 else 0.0
    tau = max(se, tau_floor)
    thr = f1_best - tau
    ok = [(int(_unpack(key, D).sum()), -f1, key) for f1, _, key in arch if f1 >= thr]
    n0, negf, key0 = min(ok)
    mask = _unpack(key0, D)
    n_eval_before = evaluator.n_evals
    removed = []
    if trim and W is not None and mask.sum() > 1:
        sel = list(np.flatnonzero(mask))
        red = {j: max((W[j, i] for i in sel if i != j), default=0.0) for j in sel}
        for j in sorted(sel, key=lambda j: -red[j]):
            if mask.sum() <= 1:
                break
            trial = mask.copy()
            trial[j] = False
            _, info = evaluator(trial)
            if info.get("macro_f1", -1) >= thr:
                mask = trial
                removed.append(int(j))
    _, info = evaluator(mask)
    return mask, dict(f1_best=round(f1_best, 5), tau=round(tau, 5), se=round(se, 5),
                      onese_n=n0, final_n=int(mask.sum()), trimmed=len(removed),
                      trim_evals=evaluator.n_evals - n_eval_before,
                      final_inner_f1=round(info.get("macro_f1", float("nan")), 5))
