"""Run ACATS inside nested cross-validation.

Examples (from the `code` folder):
    python -m framework.run_acats --dataset synthetic --profile quick
    python -m framework.run_acats --dataset ton_iot --profile laptop
    python -m framework.run_acats --dataset ton_iot --profile laptop --order random
"""
from __future__ import annotations

import argparse

import pandas as pd

from common.config import ACATS, CATS, RANDOM_STATE
from common.evaluator import FitnessEvaluator, rf_factory
from common.nested import make_inner_splits, run_nested
from common.utils import ensure_utf8_stdout

from .acats import acats_search
from .lattice import build_lattice
from .selection import one_se_select

DEFAULTS = dict(order="spectral", selector="bandit", tabu="adaptive", fitness="normalized",
                boundary="null", disc="adaptive", memory="attribute", sizew="0.02",
                final="onese")
# Proposed setting: final="onese" + sizew 0.02. Search-only setting: --final best --sizew 0.10


def variant_name(**v) -> str:
    diffs = [f"{k}-{v[k]}" for k in DEFAULTS if v[k] != DEFAULTS[k]]
    return "acats" if not diffs else "acats_" + "_".join(diffs)


def variant_params(v: dict) -> dict:
    w = float(v["sizew"])
    return dict(ACATS, boundary=v["boundary"], discretization=v["disc"], tabu_memory=v["memory"],
                weights=(round(0.95 - w, 4), w, 0.05))


def make_search_fn(order="spectral", selector="bandit", tabu="adaptive", fitness="normalized",
                   boundary="null", disc="adaptive", memory="attribute", sizew="0.02",
                   final="onese"):
    params = variant_params(dict(order=order, selector=selector, tabu=tabu, fitness=fitness,
                                 boundary=boundary, disc=disc, memory=memory, sizew=sizew))

    def search_fn(Xs, ys, ctx):
        prof, rng = ctx["profile"], ctx["rng"]
        lat_order, table, linfo = build_lattice(Xs, ctx["features"], mode=order,
                                                bins=params["mi_bins"], rng=rng,
                                                discretization=params["discretization"])
        splits = make_inner_splits(ys, prof["inner_folds"], ctx["seed"])
        weights = params["weights"] if fitness == "normalized" else CATS["weights"]
        ev = FitnessEvaluator(Xs, ys, ctx["normal"], splits,
                              rf_factory(prof["trees_search"], ctx["seed"]),
                              kind=fitness, weights=weights)
        res = acats_search(ev, lat_order, prof["iterations"], prof["n_neighbors"], params, rng,
                           selector=selector, adaptive_tabu=(tabu == "adaptive"))
        W = linfo.pop("_W")
        mask, sel_info = res["mask"], {}
        if final in ("onese", "onese_notrim"):
            mask, sel_info = one_se_select(ev, W, trim=(final == "onese"))
        rules = pd.DataFrame([dict(rule=r, **s) for r, s in res["selector_stats"].items()])
        info = dict(best_fitness=res["best_f"], fallbacks=res["fallbacks"],
                    aspirations=res["aspirations"], window=res["window"],
                    tabu_blocked_neighbours=res["tabu_blocked"],
                    inner_macro_f1=res["best_info"].get("macro_f1"), **ev.stats(),
                    **{f"lattice_{k}": v for k, v in linfo.items()},
                    **{f"final_{k}": v for k, v in sel_info.items()})
        return dict(mask=mask, history=res["history"], info=info,
                    files={"lattice": table, "rules": rules})

    return search_fn


def run(dataset, profile, seed=RANDOM_STATE, keep_identity=False, **variant):
    v = {**DEFAULTS, **{k: x for k, x in variant.items() if x is not None}}
    name = variant_name(**v)
    settings = dict(variant=v, acats_params={k: (list(x) if isinstance(x, tuple) else x)
                                             for k, x in variant_params(v).items()})
    return run_nested(dataset, profile, name, make_search_fn(**v), keep_identity=keep_identity,
                      seed=seed, extra_meta=settings)


def main():
    ensure_utf8_stdout()
    p = argparse.ArgumentParser(description="ACATS feature selection (nested CV)")
    p.add_argument("--dataset", default="synthetic")
    p.add_argument("--profile", default="quick", choices=["quick", "laptop", "full", "paper"])
    p.add_argument("--seed", type=int, default=RANDOM_STATE)
    p.add_argument("--keep-identity", action="store_true",
                   help="keep IPs / ports / timestamps (NOT recommended, for comparison only)")
    p.add_argument("--order", choices=["spectral", "spectral-unnorm", "random", "identity"], default="spectral")
    p.add_argument("--selector", default="bandit",
                   choices=["bandit", "random", "fixed30", "fixed90", "fixed110", "fixed150"])
    p.add_argument("--boundary", choices=["null", "ring"], default="null")
    p.add_argument("--tabu", choices=["adaptive", "fixed"], default="adaptive")
    p.add_argument("--fitness", choices=["normalized", "nazir"], default="normalized")
    p.add_argument("--disc", choices=["adaptive", "quantile"], default="adaptive",
                   help="MI discretisation for the lattice (quantile = first version)")
    p.add_argument("--memory", choices=["attribute", "solution"], default="attribute",
                   help="what the tabu list stores (solution = whole solutions, as in CAT-S)")
    p.add_argument("--sizew", default="0.02",
                   help="weight of |S|/D in the search fitness (proposed 0.02)")
    p.add_argument("--final", choices=["onese", "onese_notrim", "best"], default="onese",
                   help="onese = 1-SE rule + lattice-guided trimming (proposed); best = best fitness")
    a = p.parse_args()
    run(a.dataset, a.profile, a.seed, a.keep_identity, order=a.order, selector=a.selector,
        tabu=a.tabu, fitness=a.fitness, boundary=a.boundary, disc=a.disc, memory=a.memory,
        sizew=a.sizew, final=a.final)


if __name__ == "__main__":
    main()
