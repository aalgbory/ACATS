"""Ablation: remove one ACATS component at a time, same folds and seed."""
from __future__ import annotations

import argparse

import pandas as pd

from common.config import RANDOM_STATE, RESULTS_DIR
from common.utils import ensure_utf8_stdout, log

from .run_acats import run

VARIANTS = {
    "full": {},
    "order-unnorm": dict(order="spectral-unnorm"),
    "order-random": dict(order="random"),
    "order-identity": dict(order="identity"),
    "selector-fixed30": dict(selector="fixed30"),
    "selector-random": dict(selector="random"),
    "boundary-ring": dict(boundary="ring"),
    "disc-quantile": dict(disc="quantile"),
    "memory-solution": dict(memory="solution"),
    "weighted-best": dict(final="best", sizew="0.10"),
    "no-trim": dict(final="onese_notrim"),
    "tabu-fixed": dict(tabu="fixed"),
    "fitness-nazir": dict(fitness="nazir"),
}


def main():
    ensure_utf8_stdout()
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", default="synthetic")
    p.add_argument("--profile", default="quick", choices=["quick", "laptop", "full"])
    p.add_argument("--seed", type=int, default=RANDOM_STATE)
    p.add_argument("--only", nargs="*", help=f"subset of {list(VARIANTS)}")
    a = p.parse_args()
    names = a.only or list(VARIANTS)
    rows = []
    for n in names:
        log(f"##### ablation variant: {n}")
        s = run(a.dataset, a.profile, a.seed, **VARIANTS[n])
        m = s["models"]["rf"]
        rows.append(dict(variant=n, method=s["method"], n_selected=s["n_selected"],
                         macro_f1=m["macro_f1"], fpr=m["fpr"], accuracy=m["accuracy"],
                         pooled_macro_f1=m["pooled_macro_f1"], search_seconds=s["search_seconds"]))
    df = pd.DataFrame(rows)
    out = RESULTS_DIR / a.dataset / f"ablation_{a.profile}_s{a.seed}.csv"
    df.to_csv(out, index=False, encoding="utf-8-sig")
    print(df.to_string(index=False))
    log(f"Ablation table: {out}")


if __name__ == "__main__":
    main()
