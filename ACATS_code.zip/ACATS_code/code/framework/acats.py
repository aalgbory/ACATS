"""ACATS search loop (one run, inside one outer fold)."""
from __future__ import annotations

import numpy as np

from .bandit import FixedRule, RandomRule, UCB1
from .ca_rules import window_neighbours


class TabuMemory:
    """Solutions are tabu until iteration `added + tenure`."""

    def __init__(self, base: int, max_: int, step: int, adaptive: bool):
        self.base, self.max, self.step, self.adaptive = base, max_, step, adaptive
        self.tenure = base
        self.expiry: dict[bytes, int] = {}

    def add(self, key: bytes, it: int) -> None:
        self.expiry[key] = it + self.tenure

    def remaining(self, key: bytes, it: int) -> int:
        return max(self.expiry.get(key, -1) - it, 0)

    def is_tabu(self, key: bytes, it: int) -> bool:
        return self.remaining(key, it) > 0

    def on_stagnation(self) -> None:
        if self.adaptive:
            self.tenure = min(self.tenure + self.step, self.max)

    def on_improvement(self) -> None:
        if self.adaptive:
            self.tenure = self.base


class AttributeTabu(TabuMemory):
    """Recently flipped lattice cells are tabu until iteration `flipped + tenure`."""

    def __init__(self, D: int, base: int, max_: int, step: int, adaptive: bool,
                 frac: float = 0.5):
        super().__init__(base, max_, step, adaptive)
        self.cell_expiry = np.full(D, -1, dtype=np.int64)
        self.frac = frac

    def _cells(self, move) -> np.ndarray:
        return np.flatnonzero(move)

    def add(self, move, it: int) -> None:
        self.cell_expiry[self._cells(move)] = it + self.tenure

    def remaining(self, move, it: int) -> int:
        c = self._cells(move)
        return int(np.maximum(self.cell_expiry[c] - it, 0).max()) if len(c) else 0

    def is_tabu(self, move, it: int) -> bool:
        c = self._cells(move)
        return len(c) > 0 and (self.cell_expiry[c] > it).mean() >= self.frac


def acats_search(evaluator, order: np.ndarray, iterations: int, n_neighbors: int,
                 params: dict, rng: np.random.Generator, selector: str = "bandit",
                 adaptive_tabu: bool = True) -> dict:
    D = len(order)

    def to_mask(z):
        m = np.zeros(D, dtype=bool)
        m[order] = z.astype(bool)
        return m

    if selector == "bandit":
        sel = UCB1(params["rules"], c=params["ucb_c"], rng=rng)
    elif selector == "random":
        sel = RandomRule(params["rules"], rng=rng)
    else:
        sel = FixedRule(int(selector.replace("fixed", "") or 30))
    attribute = params.get("tabu_memory", "attribute") == "attribute"
    if attribute:
        tabu = AttributeTabu(D, params["tenure_base"], params["tenure_max"],
                             params["tenure_step"], adaptive_tabu, params.get("tabu_frac", 0.5))
    else:
        tabu = TabuMemory(params["tenure_base"], params["tenure_max"], params["tenure_step"],
                          adaptive_tabu)
    width = max(params["min_window"], int(round(params["window_frac"] * D)))

    z = (rng.random(D) < params["init_prob"]).astype(np.uint8)
    if z.sum() == 0:
        z[rng.integers(D)] = 1
    cur_f, cur_info = evaluator(to_mask(z))
    best_z, best_f, best_info = z.copy(), cur_f, cur_info
    if not attribute:
        tabu.add(evaluator.key(to_mask(z)), 0)

    history, stagnation, fallbacks, aspirations = [], 0, 0, 0
    for it in range(1, iterations + 1):
        rule = sel.select()
        nbs, starts = window_neighbours(z, n_neighbors, rule, width, params["boundary"], rng)
        scored = []
        for nb in nbs:
            m = to_mask(nb)
            f, info = evaluator(m)
            key = (nb != z) if attribute else evaluator.key(m)
            scored.append((f, nb, info, key))
        scored.sort(key=lambda s: s[0])
        n_tabu = int(sum(tabu.is_tabu(s_[3], it) for s_ in scored))

        chosen, how = None, "free"
        for f, nb, info, key in scored:
            if not tabu.is_tabu(key, it):
                chosen = (f, nb, info, key)
                break
            if f < best_f:
                chosen, how = (f, nb, info, key), "aspiration"
                aspirations += 1
                break
        if chosen is None:
            chosen = min(scored, key=lambda s: (tabu.remaining(s[3], it), s[0]))
            how = "fallback"
            fallbacks += 1

        f, nb, info, key = chosen
        prev_f = cur_f
        z, cur_f, cur_info = nb.copy(), f, info
        tabu.add(key, it)

        if f < best_f:
            best_z, best_f, best_info = z.copy(), f, info
            reward = params["reward_best"]
            stagnation = 0
            tabu.on_improvement()
        else:
            reward = params["reward_current"] if f < prev_f else 0.0
            stagnation += 1
            if stagnation % params["stagnation_k"] == 0:
                tabu.on_stagnation()
        sel.update(reward)

        history.append(dict(iteration=it, rule=rule, accepted=how,
                            tabu_neighbours=n_tabu, current_f=round(cur_f, 6),
                            best_f=round(best_f, 6), current_n=int(z.sum()),
                            best_n=int(best_z.sum()), best_macro_f1=best_info.get("macro_f1"),
                            tenure=tabu.tenure, reward=reward))

    return dict(mask=to_mask(best_z), best_f=best_f, best_info=best_info, history=history,
                selector_stats=sel.stats(), fallbacks=fallbacks, aspirations=aspirations,
                tabu_blocked=int(sum(h["tabu_neighbours"] for h in history)),
                window=width)
