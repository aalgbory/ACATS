"""Adaptive operator selection over CA rules."""
from __future__ import annotations

import math

import numpy as np


class UCB1:
    def __init__(self, arms, c: float = math.sqrt(2), rng: np.random.Generator | None = None):
        self.arms = list(arms)
        self.c = c
        self.n = np.zeros(len(self.arms))
        self.s = np.zeros(len(self.arms))
        self.rng = rng or np.random.default_rng()
        self._last = None

    def select(self) -> int:
        untried = np.flatnonzero(self.n == 0)
        if len(untried):
            i = int(self.rng.choice(untried))
        else:
            t = self.n.sum()
            ucb = self.s / self.n + self.c * np.sqrt(np.log(t) / self.n)
            best = np.flatnonzero(np.isclose(ucb, ucb.max()))
            i = int(self.rng.choice(best))
        self._last = i
        return self.arms[i]

    def update(self, reward: float) -> None:
        i = self._last
        self.n[i] += 1
        self.s[i] += float(np.clip(reward, 0.0, 1.0))

    def stats(self) -> dict:
        return {str(a): dict(pulls=int(n), mean_reward=round(float(s / n), 4) if n else None)
                for a, n, s in zip(self.arms, self.n, self.s)}


class FixedRule:
    """Ablation: a single rule every iteration (CAT-S uses Rule 30)."""

    def __init__(self, rule: int = 30):
        self.rule = rule
        self.n = 0
        self.s = 0.0

    def select(self) -> int:
        return self.rule

    def update(self, reward: float) -> None:
        self.n += 1
        self.s += reward

    def stats(self) -> dict:
        return {str(self.rule): dict(pulls=self.n,
                                     mean_reward=round(self.s / self.n, 4) if self.n else None)}


class RandomRule:
    """Ablation: a rule drawn uniformly at random every iteration (no learning)."""

    def __init__(self, arms, rng: np.random.Generator | None = None):
        self.arms = list(arms)
        self.rng = rng or np.random.default_rng()
        self.n = np.zeros(len(self.arms))
        self.s = np.zeros(len(self.arms))
        self._last = 0

    def select(self) -> int:
        self._last = int(self.rng.integers(len(self.arms)))
        return self.arms[self._last]

    def update(self, reward: float) -> None:
        self.n[self._last] += 1
        self.s[self._last] += reward

    def stats(self) -> dict:
        return {str(a): dict(pulls=int(n), mean_reward=round(float(s / n), 4) if n else None)
                for a, n, s in zip(self.arms, self.n, self.s)}
