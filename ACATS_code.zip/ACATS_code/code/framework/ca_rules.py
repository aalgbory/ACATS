"""Elementary (1-D, radius-1, binary) cellular automata and neighbour generators.

Wolfram encoding: the next state of a cell with neighbourhood (l, c, r) is bit number
4l + 2c + r of the rule number.  Rule 30: 111->0 110->0 101->0 100->1 011->1 010->1 001->1 000->0
"""
from __future__ import annotations

import numpy as np

LIBRARY = (30, 90, 110, 150)


def ca_step(x: np.ndarray, rule: int, boundary: str = "null") -> np.ndarray:
    """One synchronous update of the whole vector.
    boundary='ring' : cell 0 and cell D-1 are neighbours (periodic)
    boundary='null' : cells outside the lattice are fixed at 0"""
    x = np.asarray(x, dtype=np.uint8)
    if boundary == "ring":
        left, right = np.roll(x, 1), np.roll(x, -1)
    elif boundary == "null":
        left = np.concatenate(([0], x[:-1])).astype(np.uint8)
        right = np.concatenate((x[1:], [0])).astype(np.uint8)
    else:
        raise ValueError(boundary)
    idx = (left << 2) | (x << 1) | right
    return ((rule >> idx) & 1).astype(np.uint8)


def repair(z: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """A feature subset may not be empty."""
    if z.sum() == 0:
        z = z.copy()
        z[rng.integers(len(z))] = 1
    return z


# ----------------------------------------------------------------------------
# CAT-S neighbours (our reading of the paper, which does not say how 5 different
# neighbours come out of one deterministic rule): neighbour g = g-th generation of
# Rule 30 applied to the whole current vector, ring boundary.
# ----------------------------------------------------------------------------
def cats_neighbours(z: np.ndarray, k: int, rule: int, boundary: str,
                    rng: np.random.Generator, mode: str = "generations") -> list[np.ndarray]:
    """mode='generations': neighbour g = g-th generation of the rule from the current vector
       mode='perturbed'  : neighbour = one rule step applied to the current vector with one
                           random bit flipped first (5 different seeds -> 5 neighbours)"""
    z = np.asarray(z, dtype=np.uint8)
    out = []
    if mode == "generations":
        g = z
        for _ in range(k):
            g = ca_step(g, rule, boundary)
            out.append(repair(g, rng))
    elif mode == "perturbed":
        for j in rng.choice(len(z), size=min(k, len(z)), replace=False):
            seed = z.copy()
            seed[j] ^= 1
            out.append(repair(ca_step(seed, rule, boundary), rng))
    else:
        raise ValueError(mode)
    return out


# ----------------------------------------------------------------------------
# ACATS neighbours: the chosen rule is applied only inside a window of the ordered
# lattice; the k neighbours use k windows with different, evenly spread start
# positions. Because the lattice is ordered by mutual information, a window is a
# group of related features, and the move is local (a real neighbourhood).
# ----------------------------------------------------------------------------
def window_neighbours(z: np.ndarray, k: int, rule: int, width: int, boundary: str,
                      rng: np.random.Generator) -> tuple[list[np.ndarray], list[int]]:
    z = np.asarray(z, dtype=np.uint8)
    D = len(z)
    width = int(min(max(width, 1), D))
    full = ca_step(z, rule, boundary)
    if boundary == "ring":
        span = D
    else:
        span = D - width + 1
    base = int(rng.integers(span))
    starts = sorted({(base + int(round(i * span / k))) % span for i in range(k)})
    while len(starts) < k:                     # tiny lattices
        starts.append(int(rng.integers(span)))
    out = []
    for s in starts[:k]:
        pos = (s + np.arange(width)) % D
        nb = z.copy()
        nb[pos] = full[pos]
        if np.array_equal(nb, z):              # rule left this window unchanged
            nb[pos[rng.integers(width)]] ^= 1  # -> smallest possible move inside it
        out.append(repair(nb, rng))
    return out, starts[:k]
