"""Elementary (1-D, radius-1, binary) cellular automata and neighbour generators."""
from __future__ import annotations

import numpy as np

LIBRARY = (30, 90, 110, 150)


def ca_step(x: np.ndarray, rule: int, boundary: str = "null") -> np.ndarray:
    """One synchronous update of the whole vector."""
    x = np.asarray(x, dtype=np.uint8)
    if boundary == "ring":
        left, right = np.roll(x, 1), np.roll(x, -1)
    elif boundary == "null":
        left = np.concatenate(([0], x[:-1])).astype(np.uint8)
        right = np.concatenate((x[1:], [0])).astype(np.uint8)
    else:
        raise ValueError(boundary)
    idx = (left << 2) | (x << 1) | right
    return ((rule >> idx) & 1).astype(np.uint8)


def repair(z: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """A feature subset may not be empty."""
    if z.sum() == 0:
        z = z.copy()
        z[rng.integers(len(z))] = 1
    return z


def cats_neighbours(z: np.ndarray, k: int, rule: int, boundary: str,
                    rng: np.random.Generator, mode: str = "generations") -> list[np.ndarray]:
    """CAT-S neighbours: successive rule generations or rule steps on perturbed copies."""
    z = np.asarray(z, dtype=np.uint8)
    out = []
    if mode == "generations":
        g = z
        for _ in range(k):
            g = ca_step(g, rule, boundary)
            out.append(repair(g, rng))
    elif mode == "perturbed":
        for j in rng.choice(len(z), size=min(k, len(z)), replace=False):
            seed = z.copy()
            seed[j] ^= 1
            out.append(repair(ca_step(seed, rule, boundary), rng))
    else:
        raise ValueError(mode)
    return out


def window_neighbours(z: np.ndarray, k: int, rule: int, width: int, boundary: str,
                      rng: np.random.Generator) -> tuple[list[np.ndarray], list[int]]:
    z = np.asarray(z, dtype=np.uint8)
    D = len(z)
    width = int(min(max(width, 1), D))
    full = ca_step(z, rule, boundary)
    if boundary == "ring":
        span = D
    else:
        span = D - width + 1
    base = int(rng.integers(span))
    starts = sorted({(base + int(round(i * span / k))) % span for i in range(k)})
    while len(starts) < k:
        starts.append(int(rng.integers(span)))
    out = []
    for s in starts[:k]:
        pos = (s + np.arange(width)) % D
        nb = z.copy()
        nb[pos] = full[pos]
        if np.array_equal(nb, z):
            nb[pos[rng.integers(width)]] ^= 1
        out.append(repair(nb, rng))
    return out, starts[:k]
