"""Central configuration: paths, dataset registry and run profiles.

Edit DATASETS if the column names of your copy of a dataset differ
(run `python -m tools.inspect_dataset <path>` to see them).
"""
from __future__ import annotations

from pathlib import Path

# ----------------------------------------------------------------------------
# Paths (everything lives inside the P3 project folder)
# ----------------------------------------------------------------------------
CODE_DIR = Path(__file__).resolve().parents[1]
PROJECT_DIR = CODE_DIR.parent
DATA_DIR = PROJECT_DIR / "data"
CACHE_DIR = DATA_DIR / "cache"
RESULTS_DIR = PROJECT_DIR / "results"

# ----------------------------------------------------------------------------
# Dataset registry
# ----------------------------------------------------------------------------
# path         : file or folder (relative to DATA_DIR). A folder means "all *.csv inside".
# label        : column used as the class, or a list of columns joined with "_".
# normal       : the benign class value (after label construction).
# drop_always  : label / leakage columns that are never features.
# identity     : identity / shortcut features (IPs, ports, timestamps, ids).
#                Dropped unless --keep-identity is given.
# class_map    : optional function name in data.py that maps raw labels to groups.
DATASETS: dict[str, dict] = {
    # TON_IoT network (train_test_network.csv). The copy checked on 13-11-2026 has
    # 211,043 rows and NO 'ts' column (Nazir's Fig. 7 sums to 461,041 rows: another release).
    "ton_iot": {
        "path": "ton_iot/train_test_network.csv",
        "label": "type",
        "normal": "normal",
        "drop_always": ["label", "type"],
        "identity": ["ts", "src_ip", "dst_ip", "src_port", "dst_port"],
        "class_map": None,
    },
    # NF-BoT-IoT-v3 (NetFlow v3 version of BoT-IoT, one CSV). Column names follow the
    # NetFlow v3 schema; verify with  python -m tools.inspect_dataset ..\data\bot_iot
    "bot_iot": {
        "path": "bot_iot",
        "label": "Attack",
        "normal": "Benign",
        "drop_always": ["Label", "Attack"],
        "identity": ["IPV4_SRC_ADDR", "IPV4_DST_ADDR", "L4_SRC_PORT", "L4_DST_PORT",
                     "FLOW_START_MILLISECONDS", "FLOW_END_MILLISECONDS", "DNS_QUERY_ID"],
        "class_map": None,
    },
    # original BoT-IoT (Argus CSVs) - only if you add them to data/bot_iot_original
    "bot_iot_original": {
        "path": "bot_iot_original",
        "label": ["category", "subcategory"],
        "normal": "Normal_Normal",
        "drop_always": ["attack", "category", "subcategory"],
        "identity": ["pkSeqID", "stime", "ltime", "saddr", "daddr",
                     "sport", "dport", "seq"],
        "class_map": None,
    },
    # CICIoT2023, per-pcap CSV release: one folder per attack, NO label column.
    # The class is the folder name (34 classes) grouped into 8 (see data.ciciot_8class).
    "ciciot2023": {
        "path": "ciciot2023",
        "label": "__folder__",
        "normal": "Benign",
        "drop_always": ["__folder__", "label"],
        "identity": [],            # these CSVs carry no IPs / ports / timestamps
        "class_map": "ciciot_8class",
    },
    # produced by `python -m tools.make_synthetic`
    "synthetic": {
        "path": "synthetic/synthetic.csv",
        "label": "attack_cat",
        "normal": "normal",
        "drop_always": ["attack_cat", "is_attack"],
        "identity": ["ts", "src_ip", "dst_ip", "src_port", "dst_port"],
        "class_map": None,
    },
}

# ----------------------------------------------------------------------------
# Run profiles  (--profile quick | laptop | full)
# ----------------------------------------------------------------------------
# max_rows        : stratified cap applied right after loading
# rows_per_file   : cap per CSV when a dataset is a folder of many CSVs
# min_per_class   : every class keeps at least this many rows in each cap (if available)
# min_class_rows  : classes with fewer rows than this are dropped (with a warning)
# search_rows     : rows of the outer-train fold given to the search (fitness sample)
# outer_folds     : outer CV folds (evaluation)
# inner_folds     : inner CV folds (fitness inside the search)
# iterations      : search iterations (paper: 100)
# n_neighbors     : neighbours per iteration (paper: 5)
# trees_search    : RF trees in the fitness surrogate
# trees_final     : RF trees for the final model on S*
# runs            : independent runs for the faithful reproduction (paper: 100)
# svm_search_rows / svm_final_rows : smaller caps for the SVM baseline (Dey)
# nsga_pop / nsga_gens : NSGA-II size for the Dey baseline
PROFILES: dict[str, dict] = {
    "quick": dict(max_rows=6000, rows_per_file=1500, min_per_class=40, min_class_rows=20,
                  search_rows=2000, outer_folds=2, inner_folds=2, iterations=12,
                  n_neighbors=5, trees_search=15, trees_final=30, runs=2,
                  svm_search_rows=1000, svm_final_rows=3000, nsga_pop=10, nsga_gens=4),
    "laptop": dict(max_rows=60000, rows_per_file=2500, min_per_class=300, min_class_rows=30,
                   search_rows=12000, outer_folds=3, inner_folds=2, iterations=50,
                   n_neighbors=5, trees_search=40, trees_final=100, runs=5,
                   svm_search_rows=4000, svm_final_rows=15000, nsga_pop=20, nsga_gens=15),
    "full": dict(max_rows=300000, rows_per_file=10000, min_per_class=1000, min_class_rows=50,
                 search_rows=40000, outer_folds=5, inner_folds=3, iterations=100,
                 n_neighbors=5, trees_search=100, trees_final=200, runs=30,
                 svm_search_rows=10000, svm_final_rows=50000, nsga_pop=40, nsga_gens=30),
    # closest to Nazir's own setup: ALL rows, 100 iterations (Table 3), final RF with
    # 500 trees (ranger's default). The search ranks subsets on a 30k-row sample with
    # 100 trees, otherwise one run would take a day on an 8 GB laptop.
    "paper": dict(max_rows=None, rows_per_file=20000, min_per_class=1000, min_class_rows=50,
                  search_rows=30000, outer_folds=5, inner_folds=3, iterations=100,
                  n_neighbors=5, trees_search=100, trees_final=500, runs=10,
                  svm_search_rows=10000, svm_final_rows=50000, nsga_pop=40, nsga_gens=30),
}

# ----------------------------------------------------------------------------
# ACATS defaults
# ----------------------------------------------------------------------------
ACATS = dict(
    # fitness = w1*(1 - MacroF1) + w2*|S|/D + w3*FPR
    # With equal weights the |S|/D term (~0.3) would still dwarf the error term (~0.02),
    # repeating Nazir's problem. With these weights dropping one feature (D~40) is worth
    # about 0.0014 of Macro-F1.
    weights=(0.85, 0.10, 0.05),     # search-only weights (the proposed run overrides w2 = 0.02)
    rules=(30, 90, 110, 150),
    ucb_c=2 ** 0.5,
    reward_best=1.0,        # bandit reward when the move improves the global best
    reward_current=0.5,     # ... when it only improves on the current solution
    window_frac=0.25,       # CA is applied to a window of this fraction of the lattice
    min_window=3,
    boundary="null",        # linear lattice: the two ends are the LEAST similar features
    tabu_memory="attribute",  # flipped cells are tabu (alternative: whole solutions)
    tabu_frac=1.0,            # a move is tabu if ALL cells it flips are tabu (0.5 blocked 84 % of moves)
    discretization="adaptive",  # sparse features keep their information (alternative: quantile)
    tenure_base=7,
    tenure_max=15,
    tenure_step=2,
    stagnation_k=8,         # iterations without a new best before tenure grows
    mi_bins=16,
    init_prob=0.5,
)

# CAT-S as published (Nazir et al. 2023, Table 3)
CATS = dict(
    rule=30,
    tabu_size=7,
    aspiration=0.02,
    weights=(0.333, 0.333, 0.333),
    boundary="ring",
)

RANDOM_STATE = 42
