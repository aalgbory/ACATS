"""Central configuration: paths, dataset registry and run profiles."""
from __future__ import annotations

from pathlib import Path

CODE_DIR = Path(__file__).resolve().parents[1]
PROJECT_DIR = CODE_DIR.parent
DATA_DIR = PROJECT_DIR / "data"
CACHE_DIR = DATA_DIR / "cache"
RESULTS_DIR = PROJECT_DIR / "results"

DATASETS: dict[str, dict] = {
    "ton_iot": {
        "path": "ton_iot/train_test_network.csv",
        "label": "type",
        "normal": "normal",
        "drop_always": ["label", "type"],
        "identity": ["ts", "src_ip", "dst_ip", "src_port", "dst_port"],
        "class_map": None,
    },
    "bot_iot": {
        "path": "bot_iot",
        "label": "Attack",
        "normal": "Benign",
        "drop_always": ["Label", "Attack"],
        "identity": ["IPV4_SRC_ADDR", "IPV4_DST_ADDR", "L4_SRC_PORT", "L4_DST_PORT",
                     "FLOW_START_MILLISECONDS", "FLOW_END_MILLISECONDS", "DNS_QUERY_ID"],
        "class_map": None,
    },
    "bot_iot_original": {
        "path": "bot_iot_original",
        "label": ["category", "subcategory"],
        "normal": "Normal_Normal",
        "drop_always": ["attack", "category", "subcategory"],
        "identity": ["pkSeqID", "stime", "ltime", "saddr", "daddr",
                     "sport", "dport", "seq"],
        "class_map": None,
    },
    "ciciot2023": {
        "path": "ciciot2023",
        "label": "__folder__",
        "normal": "Benign",
        "drop_always": ["__folder__", "label"],
        "identity": [],
        "class_map": "ciciot_8class",
    },
    "synthetic": {
        "path": "synthetic/synthetic.csv",
        "label": "attack_cat",
        "normal": "normal",
        "drop_always": ["attack_cat", "is_attack"],
        "identity": ["ts", "src_ip", "dst_ip", "src_port", "dst_port"],
        "class_map": None,
    },
}

PROFILES: dict[str, dict] = {
    "quick": dict(max_rows=6000, rows_per_file=1500, min_per_class=40, min_class_rows=20,
                  search_rows=2000, outer_folds=2, inner_folds=2, iterations=12,
                  n_neighbors=5, trees_search=15, trees_final=30, runs=2,
                  svm_search_rows=1000, svm_final_rows=3000, nsga_pop=10, nsga_gens=4),
    "laptop": dict(max_rows=60000, rows_per_file=2500, min_per_class=300, min_class_rows=30,
                   search_rows=12000, outer_folds=3, inner_folds=2, iterations=50,
                   n_neighbors=5, trees_search=40, trees_final=100, runs=5,
                   svm_search_rows=4000, svm_final_rows=15000, nsga_pop=20, nsga_gens=15),
    "full": dict(max_rows=300000, rows_per_file=10000, min_per_class=1000, min_class_rows=50,
                 search_rows=40000, outer_folds=5, inner_folds=3, iterations=100,
                 n_neighbors=5, trees_search=100, trees_final=200, runs=30,
                 svm_search_rows=10000, svm_final_rows=50000, nsga_pop=40, nsga_gens=30),
    "paper": dict(max_rows=None, rows_per_file=20000, min_per_class=1000, min_class_rows=50,
                  search_rows=30000, outer_folds=5, inner_folds=3, iterations=100,
                  n_neighbors=5, trees_search=100, trees_final=500, runs=10,
                  svm_search_rows=10000, svm_final_rows=50000, nsga_pop=40, nsga_gens=30),
}

ACATS = dict(
    weights=(0.85, 0.10, 0.05),
    rules=(30, 90, 110, 150),
    ucb_c=2 ** 0.5,
    reward_best=1.0,
    reward_current=0.5,
    window_frac=0.25,
    min_window=3,
    boundary="null",
    tabu_memory="attribute",
    tabu_frac=1.0,
    discretization="adaptive",
    tenure_base=7,
    tenure_max=15,
    tenure_step=2,
    stagnation_k=8,
    mi_bins=16,
    init_prob=0.5,
)

CATS = dict(
    rule=30,
    tabu_size=7,
    aspiration=0.02,
    weights=(0.333, 0.333, 0.333),
    boundary="ring",
)

RANDOM_STATE = 42
