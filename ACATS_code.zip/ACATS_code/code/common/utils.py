"""Small helpers: logging, timing, JSON output."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

_T0 = time.time()


def log(msg: str) -> None:
    el = time.time() - _T0
    print(f"[{int(el // 60):3d}m{int(el % 60):02d}s] {msg}", flush=True)


class Timer:
    def __enter__(self):
        self.t = time.perf_counter()
        return self

    def __exit__(self, *a):
        self.seconds = time.perf_counter() - self.t


def _default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, Path):
        return str(o)
    return str(o)


def save_json(obj, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False, default=_default)


def mean_std(values) -> str:
    v = np.asarray(values, dtype=float)
    if len(v) == 0:
        return "n/a"
    return f"{v.mean():.4f} ± {v.std(ddof=1) if len(v) > 1 else 0.0:.4f}"


def ensure_utf8_stdout() -> None:
    """Windows cmd may not print non-ASCII; never crash because of it."""
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass
