"""Loading, cleaning and sampling of the IoT datasets."""
from __future__ import annotations

import glob
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from .config import CACHE_DIR, DATA_DIR, DATASETS
from .utils import log

MISSING_TOKENS = ["-", "", " ", "?", "nan", "NaN", "None", "none"]
CHUNK_ROWS = 500_000


def ciciot_8class(label: str) -> str:
    """CICIoT2023: 34 raw classes -> 8 groups used by the dataset authors."""
    s = str(label).strip()
    u = s.upper()
    if u.startswith("BENIGN"):
        return "Benign"
    if u.startswith("DDOS"):
        return "DDoS"
    if u.startswith("DOS"):
        return "DoS"
    if u.startswith("MIRAI"):
        return "Mirai"
    if u.startswith("RECON") or "VULNERABILITYSCAN" in u:
        return "Recon"
    if "SPOOFING" in u:
        return "Spoofing"
    if "BRUTEFORCE" in u:
        return "BruteForce"
    if u in {"SQLINJECTION", "XSS", "COMMANDINJECTION", "BACKDOOR_MALWARE",
             "UPLOADING_ATTACK", "BROWSERHIJACKING"}:
        return "Web"
    return s


CLASS_MAPS = {"ciciot_8class": ciciot_8class}


def stratified_cap(y: np.ndarray, n_total: int | None, min_per_class: int,
                   rng: np.random.Generator) -> np.ndarray:
    """Stratified row sample of about n_total rows that keeps at least min_per_class rows per class."""
    y = np.asarray(y)
    n = len(y)
    if n_total is None or n <= n_total:
        return np.arange(n)
    classes, counts = np.unique(y, return_counts=True)
    floor = np.minimum(counts, min_per_class)
    remaining = max(n_total - floor.sum(), 0)
    extra_pool = counts - floor
    if extra_pool.sum() > 0:
        extra = np.floor(extra_pool / extra_pool.sum() * remaining).astype(int)
    else:
        extra = np.zeros_like(counts)
    take = np.minimum(floor + extra, counts)
    idx = []
    for c, k in zip(classes, take):
        rows = np.flatnonzero(y == c)
        idx.append(rng.choice(rows, size=int(k), replace=False))
    return np.sort(np.concatenate(idx))


def _list_csvs(path: Path) -> list[Path]:
    if path.is_file():
        return [path]
    files = sorted(Path(p) for p in glob.glob(str(path / "**" / "*.csv"), recursive=True))
    if not files:
        raise FileNotFoundError(f"No CSV files found under {path}")
    return files


def _build_label(df: pd.DataFrame, spec) -> pd.Series:
    if isinstance(spec, (list, tuple)):
        missing = [c for c in spec if c not in df.columns]
        if missing:
            raise KeyError(f"Label columns {missing} not found. Columns: {list(df.columns)[:60]}")
        lab = df[spec[0]].astype(str).str.strip()
        for c in spec[1:]:
            lab = lab + "_" + df[c].astype(str).str.strip()
        return lab
    if spec not in df.columns:
        raise KeyError(f"Label column '{spec}' not found. Columns: {list(df.columns)[:60]}")
    return df[spec].astype(str).str.strip()


def _count_lines(path: Path) -> int:
    n = 0
    with open(path, "rb") as fh:
        while True:
            buf = fh.read(1 << 24)
            if not buf:
                break
            n += buf.count(b"\n")
    return max(n - 1, 1)


def _clean_columns(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [str(c).replace("﻿", "").strip() for c in df.columns]
    return df


def _read_many(files: list[Path], cfg: dict, profile: dict,
               rng: np.random.Generator) -> pd.DataFrame:
    """Read one or many CSV files in chunks with stratified subsampling to limit memory use."""
    parts = []
    many = len(files) > 1
    rows_per_file, max_rows = profile["rows_per_file"], profile["max_rows"]
    floor = profile["min_per_class"]
    for i, f in enumerate(files, 1):
        rate = None
        if not many and max_rows and f.stat().st_size > 200e6:
            log(f"  counting rows of {f.name} ({f.stat().st_size / 1e9:.1f} GB) ...")
            n_lines = _count_lines(f)
            rate = min(1.0, 1.5 * max_rows / n_lines)
            log(f"  {n_lines:,} rows; sampling about {rate:.2%} of every chunk")
        chunks = []
        for ch in pd.read_csv(f, low_memory=False, chunksize=CHUNK_ROWS, encoding="utf-8-sig"):
            ch = _clean_columns(ch)
            if cfg["label"] == "__folder__":
                ch["__folder__"] = f.parent.name
            if many and rows_per_file and len(ch) > rows_per_file:
                lab = _build_label(ch, cfg["label"]).to_numpy()
                ch = ch.iloc[stratified_cap(lab, rows_per_file, max(1, rows_per_file // 50), rng)]
            elif rate is not None and rate < 1.0:
                lab = _build_label(ch, cfg["label"]).to_numpy()
                ch = ch.iloc[stratified_cap(lab, int(len(ch) * rate) + 1,
                                            max(1, floor // 10), rng)]
            chunks.append(ch)
        df = pd.concat(chunks, ignore_index=True)
        if many and rows_per_file and len(df) > rows_per_file:
            lab = _build_label(df, cfg["label"]).to_numpy()
            df = df.iloc[stratified_cap(lab, rows_per_file, max(1, rows_per_file // 50), rng)]
        parts.append(df)
        if many and (i % 20 == 0 or i == len(files)):
            log(f"  read {i}/{len(files)} files")
    return pd.concat(parts, ignore_index=True)


def _to_numeric_frame(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    out = {}
    encoded = []
    for c in df.columns:
        s = df[c]
        if pd.api.types.is_bool_dtype(s):
            out[c] = s.astype(np.float32)
            continue
        if pd.api.types.is_numeric_dtype(s):
            out[c] = pd.to_numeric(s, errors="coerce")
            continue
        s = s.astype(str).str.strip()
        s = s.where(~s.isin(MISSING_TOKENS), other=np.nan)
        num = pd.to_numeric(s, errors="coerce")
        non_missing = s.notna().sum()
        if non_missing == 0 or num.notna().sum() >= 0.95 * non_missing:
            out[c] = num
        else:
            codes, _ = pd.factorize(s, sort=True)
            out[c] = pd.Series(codes, index=s.index).where(codes >= 0, np.nan)
            encoded.append(c)
    X = pd.DataFrame(out, index=df.index)
    X = X.replace([np.inf, -np.inf], np.nan).fillna(-1).astype(np.float32)
    return X, encoded


def load_dataset(name: str, profile: dict, keep_identity: bool = False,
                 seed: int = 42, use_cache: bool = True):
    """Return (X: DataFrame float32, y: ndarray[str], meta: dict)."""
    if name not in DATASETS:
        raise KeyError(f"Unknown dataset '{name}'. Known: {list(DATASETS)}")
    cfg = DATASETS[name]
    key = json.dumps([name, cfg, profile["max_rows"], profile["rows_per_file"],
                      profile["min_per_class"], profile["min_class_rows"], keep_identity, seed],
                     sort_keys=True, default=str)
    tag = hashlib.md5(key.encode()).hexdigest()[:10]
    cache = CACHE_DIR / f"{name}_{tag}.pkl"
    if use_cache and cache.exists():
        log(f"Loading cached data: {cache.name}")
        obj = pd.read_pickle(cache)
        return obj["X"], obj["y"], obj["meta"]

    rng = np.random.default_rng(seed)
    path = DATA_DIR / cfg["path"]
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset '{name}' not found at {path}\n"
            f"Copy the data there (see README) or edit common/config.py")
    files = _list_csvs(path)
    log(f"Reading {name}: {len(files)} file(s) from {path}")
    df = _read_many(files, cfg, profile, rng)
    n_raw = len(df)

    y = _build_label(df, cfg["label"])
    cmap = cfg.get("class_map")
    if cmap:
        y = y.map(CLASS_MAPS[cmap])
    y = y.to_numpy(dtype=object).astype(str)

    drop = [c for c in cfg["drop_always"] if c in df.columns]
    identity_present = [c for c in cfg["identity"] if c in df.columns]
    if not keep_identity:
        drop += identity_present
    df = df.drop(columns=drop)

    idx = stratified_cap(y, profile["max_rows"], profile["min_per_class"], rng)
    df = df.iloc[idx].reset_index(drop=True)
    y = y[idx]

    classes, counts = np.unique(y, return_counts=True)
    tiny = classes[counts < profile["min_class_rows"]]
    if len(tiny):
        log(f"WARNING: dropping tiny classes {dict(zip(tiny, counts[counts < profile['min_class_rows']]))}")
        keep = ~np.isin(y, tiny)
        df = df.loc[keep].reset_index(drop=True)
        y = y[keep]

    X, encoded = _to_numeric_frame(df)
    const = [c for c in X.columns if X[c].nunique(dropna=False) <= 1]
    if const:
        X = X.drop(columns=const)

    normal = cfg["normal"]
    if normal not in set(y):
        log(f"WARNING: normal class '{normal}' not present. Classes: {sorted(set(y))[:20]}")
    classes, counts = np.unique(y, return_counts=True)
    meta = dict(
        dataset=name, n_raw_rows=int(n_raw), n_rows=int(len(y)), n_features=int(X.shape[1]),
        features=list(X.columns), normal=normal,
        identity_dropped=[] if keep_identity else identity_present,
        identity_kept=identity_present if keep_identity else [],
        text_encoded=encoded, constant_dropped=const,
        class_counts={str(c): int(k) for c, k in zip(classes, counts)},
    )
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    pd.to_pickle({"X": X, "y": y, "meta": meta}, cache)
    log(f"{name}: {meta['n_rows']} rows x {meta['n_features']} features, "
        f"{len(classes)} classes (cached as {cache.name})")
    return X, y, meta
