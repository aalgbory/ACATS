"""Nested cross-validation driver shared by cats_fixed, ACATS, the ablation and baselines.

Outer loop (evaluation)                    Inner loop (inside search_fn)
-----------------------                    ----------------------------
for each outer fold:                       fitness of a mask = surrogate RF trained /
   search sample  <- outer-train only        tested on the inner folds of the search sample
   S* = search_fn(search sample)
   final model on outer-train[S*]
   metrics on outer-test (never seen)
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold

from .config import PROFILES, RESULTS_DIR
from .data import load_dataset, stratified_cap
from .evaluator import rf_factory
from .metrics import all_metrics, macro_f1, per_class_f1
from .utils import Timer, log, mean_std, save_json


def safe_n_splits(y, k: int) -> int:
    _, counts = np.unique(y, return_counts=True)
    return int(max(2, min(k, counts.min())))


def make_inner_splits(y, k: int, seed: int):
    k = safe_n_splits(y, k)
    skf = StratifiedKFold(n_splits=k, shuffle=True, random_state=seed)
    return list(skf.split(np.zeros(len(y)), y))


def make_holdout_split(y, test_size: float, seed: int):
    from sklearn.model_selection import train_test_split
    idx = np.arange(len(y))
    tr, te = train_test_split(idx, test_size=test_size, stratify=y, random_state=seed)
    return [(tr, te)]


def _plot_convergence(histories: dict[int, pd.DataFrame], path: Path, title: str):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return
    fig, ax = plt.subplots(figsize=(7, 4))
    for k, h in histories.items():
        if "best_f" in h:
            ax.plot(h["iteration"], h["best_f"], label=f"fold {k} best")
        if "current_f" in h:
            ax.plot(h["iteration"], h["current_f"], alpha=0.3, linestyle="--")
    ax.set_xlabel("iteration")
    ax.set_ylabel("fitness (lower is better)")
    ax.set_title(title)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


def run_nested(dataset: str, profile_name: str, method: str,
               search_fn: Callable[[np.ndarray, np.ndarray, dict], dict],
               final_models: dict | None = None, keep_identity: bool = False,
               seed: int = 42, extra_meta: dict | None = None,
               reference_all_features: bool = True) -> dict:
    """search_fn(X_search, y_search, ctx) -> dict(mask=bool array, history=list[dict]|None,
    info=dict|None, files=dict[name -> DataFrame]|None)

    final_models: {name: (factory, max_train_rows or None)}; default = RF(trees_final)."""
    profile = PROFILES[profile_name]
    X_df, y, meta = load_dataset(dataset, profile, keep_identity=keep_identity, seed=seed)
    X = X_df.to_numpy(dtype=np.float32)
    feats = np.array(meta["features"])
    normal = meta["normal"]
    if final_models is None:
        final_models = {"rf": (rf_factory(profile["trees_final"], seed), None)}

    tag = "keepid" if keep_identity else "noid"
    out_dir = RESULTS_DIR / dataset / f"{method}_{profile_name}_{tag}_s{seed}"
    out_dir.mkdir(parents=True, exist_ok=True)
    log(f"=== {method} | {dataset} | profile={profile_name} | {X.shape[0]} rows x "
        f"{X.shape[1]} features | identity {'KEPT' if keep_identity else 'dropped'} ===")

    n_outer = safe_n_splits(y, profile["outer_folds"])
    outer = StratifiedKFold(n_splits=n_outer, shuffle=True, random_state=seed)
    n_classes = len(np.unique(y))

    fold_rows, histories, masks = [], {}, []
    pooled = {m: ([], []) for m in final_models}
    if reference_all_features:
        pooled["all_features_rf"] = ([], [])

    for k, (tr, te) in enumerate(outer.split(np.zeros(len(y)), y)):
        rng = np.random.default_rng(seed * 1000 + k)
        mpc = max(10, min(profile["min_per_class"], profile["search_rows"] // (2 * n_classes)))
        s_idx = tr[stratified_cap(y[tr], profile["search_rows"], mpc, rng)]
        ctx = dict(fold=k, profile=profile, profile_name=profile_name, normal=normal,
                   features=list(feats), seed=seed + k, out_dir=out_dir, rng=rng)
        log(f"[fold {k + 1}/{n_outer}] search on {len(s_idx)} rows of outer-train")
        with Timer() as t:
            res = search_fn(X[s_idx], y[s_idx], ctx)
        mask = np.asarray(res["mask"], dtype=bool)
        masks.append(mask)
        row = dict(fold=k, n_selected=int(mask.sum()), search_seconds=round(t.seconds, 1))
        row.update({f"search_{a}": b for a, b in (res.get("info") or {}).items()
                    if np.isscalar(b)})

        cols = np.flatnonzero(mask)
        for mname, (factory, cap) in final_models.items():
            tr_use = tr
            if cap is not None and len(tr) > cap:
                tr_use = tr[stratified_cap(y[tr], cap, max(10, cap // (3 * n_classes)), rng)]
            model = factory()
            model.fit(X[np.ix_(tr_use, cols)], y[tr_use])
            pred = model.predict(X[np.ix_(te, cols)])
            met = all_metrics(y[te], pred, normal)
            row.update({f"{mname}_{a}": b for a, b in met.items()})
            pooled[mname][0].append(y[te])
            pooled[mname][1].append(pred)

        if reference_all_features:
            ref = rf_factory(profile["trees_final"], seed)()
            ref.fit(X[tr], y[tr])
            pred = ref.predict(X[te])
            met = all_metrics(y[te], pred, normal)
            row.update({f"all_features_rf_{a}": b for a, b in met.items()})
            pooled["all_features_rf"][0].append(y[te])
            pooled["all_features_rf"][1].append(pred)

        fold_rows.append(row)
        first = next(iter(final_models))
        log(f"[fold {k + 1}] |S*|={mask.sum()}/{len(mask)}  "
            f"{first}: MacroF1={row[f'{first}_macro_f1']:.4f} FPR={row[f'{first}_fpr']:.4f}  "
            f"search {t.seconds:.0f}s")
        if res.get("history"):
            h = pd.DataFrame(res["history"])
            h.to_csv(out_dir / f"history_fold{k}.csv", index=False)
            histories[k] = h
        for fname, df in (res.get("files") or {}).items():
            df.to_csv(out_dir / f"{fname}_fold{k}.csv", index=False)

    # ---------------------------------------------------------------- aggregate
    folds = pd.DataFrame(fold_rows)
    folds.to_csv(out_dir / "folds.csv", index=False)
    M = np.vstack(masks)
    freq = pd.DataFrame({"feature": feats, "selected_in_folds": M.sum(0),
                         "frequency": M.mean(0)}).sort_values(
        ["frequency", "feature"], ascending=[False, True])
    freq.to_csv(out_dir / "feature_frequency.csv", index=False)

    summary = dict(method=method, dataset=dataset, profile=profile_name, seed=seed,
                   identity="kept" if keep_identity else "dropped",
                   n_rows=meta["n_rows"], n_features_total=int(X.shape[1]),
                   outer_folds=n_outer, class_counts=meta["class_counts"],
                   n_selected=mean_std(folds["n_selected"]),
                   search_seconds=mean_std(folds["search_seconds"]),
                   features_selected_in_all_folds=list(freq.loc[freq.frequency == 1.0, "feature"]),
                   models={})
    pcf = {}
    for mname, (yt, yp) in pooled.items():
        yt, yp = np.concatenate(yt), np.concatenate(yp)
        summary["models"][mname] = {
            m: mean_std(folds[f"{mname}_{m}"]) for m in ("accuracy", "macro_f1", "fpr", "weighted_fpr")}
        summary["models"][mname]["pooled_macro_f1"] = round(macro_f1(yt, yp), 4)
        pcf[mname] = per_class_f1(yt, yp)
    pd.DataFrame(pcf).to_csv(out_dir / "per_class_f1.csv")
    if extra_meta:
        summary["settings"] = extra_meta
    save_json(summary, out_dir / "summary.json")
    save_json(meta, out_dir / "data_meta.json")
    if histories:
        _plot_convergence(histories, out_dir / "convergence.png", f"{method} on {dataset}")

    log(f"--- {method} on {dataset}: |S| = {summary['n_selected']}, "
        f"search time = {summary['search_seconds']} s")
    for mname, d in summary["models"].items():
        log(f"    {mname:16s} MacroF1 {d['macro_f1']}  FPR {d['fpr']}  Acc {d['accuracy']}")
    log(f"Results saved in {out_dir}")
    return summary
