"""Cached wrapper fitness evaluator.

A candidate is a boolean mask over the feature columns. Its fitness is obtained by
training the surrogate model on each (train, test) split given at construction, pooling
the test predictions, and computing the metrics once on the pooled predictions.
Masks already seen are answered from a cache (the search revisits solutions often).
"""
from __future__ import annotations

import time

import numpy as np
from sklearn.ensemble import RandomForestClassifier

from .metrics import all_metrics, macro_f1, nazir_cost, normalized_fitness


def rf_factory(n_trees: int, seed: int, n_jobs: int = -1):
    def make():
        return RandomForestClassifier(n_estimators=n_trees, n_jobs=n_jobs,
                                      random_state=seed, min_samples_leaf=1)
    return make


class FitnessEvaluator:
    def __init__(self, X: np.ndarray, y: np.ndarray, normal: str, splits,
                 model_factory, kind: str = "normalized", weights=(0.9, 0.05, 0.05)):
        assert kind in ("normalized", "nazir")
        self.X = np.ascontiguousarray(X, dtype=np.float32)
        self.y = np.asarray(y)
        self.normal = normal
        self.splits = list(splits)
        self.make = model_factory
        self.kind = kind
        self.weights = weights
        self.D = self.X.shape[1]
        self.cache: dict[bytes, tuple[float, dict]] = {}
        self.n_evals = 0
        self.n_hits = 0
        self.seconds = 0.0
        self._y_pool = np.concatenate([self.y[te] for _, te in self.splits])

    def key(self, mask: np.ndarray) -> bytes:
        return np.packbits(mask.astype(bool)).tobytes()

    def __call__(self, mask: np.ndarray) -> tuple[float, dict]:
        mask = np.asarray(mask, dtype=bool)
        k = self.key(mask)
        if k in self.cache:
            self.n_hits += 1
            return self.cache[k]
        t = time.perf_counter()
        n_sel = int(mask.sum())
        if n_sel == 0:
            res = (float("inf"), dict(n=0))
            self.cache[k] = res
            return res
        cols = np.flatnonzero(mask)
        preds, fold_f1 = [], []
        for tr, te in self.splits:
            m = self.make()
            m.fit(self.X[np.ix_(tr, cols)], self.y[tr])
            p = m.predict(self.X[np.ix_(te, cols)])
            preds.append(p)
            fold_f1.append(macro_f1(self.y[te], p))
        pred = np.concatenate(preds)
        met = all_metrics(self._y_pool, pred, self.normal)
        if self.kind == "nazir":
            f = nazir_cost(met["accuracy"], n_sel, met["weighted_fpr"], self.weights)
        else:
            f = normalized_fitness(met["macro_f1"], n_sel, self.D, met["fpr"], self.weights)
        met["n"] = n_sel
        met["fold_f1"] = fold_f1
        res = (float(f), met)
        self.cache[k] = res
        self.n_evals += 1
        self.seconds += time.perf_counter() - t
        return res

    def stats(self) -> dict:
        return dict(n_evals=self.n_evals, cache_hits=self.n_hits,
                    eval_seconds=round(self.seconds, 2))
