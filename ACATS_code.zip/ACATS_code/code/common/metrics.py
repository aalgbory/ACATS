"""Evaluation metrics.

* Macro-F1 is computed over the classes PRESENT in y_true (lesson from P1).
* FPR (binary)  : fraction of normal traffic flagged as any attack  -> IDS false alarm rate.
* FPR (weighted): per-class one-vs-rest FPR averaged with class-support weights
                  (our reading of the "weighted false positive rate" in Nazir et al.).
"""
from __future__ import annotations

import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score


def binary_fpr(y_true, y_pred, normal: str) -> float:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    m = y_true == normal
    if m.sum() == 0:
        return float("nan")
    return float((y_pred[m] != normal).mean())


def weighted_fpr(y_true, y_pred) -> float:
    labels = np.unique(y_true)
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    total = cm.sum()
    fprs, w = [], []
    for i in range(len(labels)):
        fp = cm[:, i].sum() - cm[i, i]
        neg = total - cm[i].sum()
        fprs.append(fp / neg if neg else 0.0)
        w.append(cm[i].sum())
    return float(np.average(fprs, weights=w))


def macro_f1(y_true, y_pred) -> float:
    labels = np.unique(y_true)
    return float(f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0))


def per_class_f1(y_true, y_pred) -> dict:
    labels = np.unique(y_true)
    vals = f1_score(y_true, y_pred, labels=labels, average=None, zero_division=0)
    return {str(l): float(v) for l, v in zip(labels, vals)}


def all_metrics(y_true, y_pred, normal: str) -> dict:
    return dict(
        accuracy=float(accuracy_score(y_true, y_pred)),
        macro_f1=macro_f1(y_true, y_pred),
        fpr=binary_fpr(y_true, y_pred, normal),
        weighted_fpr=weighted_fpr(y_true, y_pred),
    )


# ----------------------------------------------------------------------------
# Fitness / cost functions (lower is better for both)
# ----------------------------------------------------------------------------
def nazir_cost(accuracy: float, n_selected: int, wfpr: float,
               weights=(0.333, 0.333, 0.333)) -> float:
    """Eq. (3) of Nazir et al.: e = 100 - Accuracy(%), n = raw feature count."""
    e = 100.0 - 100.0 * accuracy
    return weights[0] * e + weights[1] * n_selected + weights[2] * wfpr


def normalized_fitness(macro: float, n_selected: int, n_total: int, fpr: float,
                       weights=(0.90, 0.05, 0.05)) -> float:
    """ACATS: w1*(1-MacroF1) + w2*|S|/D + w3*FPR, every term in [0, 1]."""
    fpr = 0.0 if np.isnan(fpr) else fpr
    return weights[0] * (1.0 - macro) + weights[1] * n_selected / n_total + weights[2] * fpr
