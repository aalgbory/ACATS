"""Paired comparison of methods over several seeds (every fold of every seed is one pair).

    python -m tools.compare_seeds --dataset ton_iot --profile laptop --seeds 101 202 303

Methods compared (folders produced by the commands in README, section "Reproducing the comparison"):
  acats            ACATS (1-SE rule + lattice-guided trimming)
  acats_search     ACATS search only (weighted fitness 0.85/0.10/0.05, best solution)
  cats_best        CAT-S, corrected evaluation, best solution (same weights as acats_search)
  cats_onese       CAT-S + the ACATS final selection (control: is the gain the rule or ACATS?)
  all_features     RF on every feature
Paired test: Wilcoxon signed-rank on the per-fold Macro-F1 differences.
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

from common.config import RESULTS_DIR

FOLDERS = {
    "acats": "acats_{p}_noid_s{s}",
    "acats_search": "acats_sizew-0.10_final-best_{p}_noid_s{s}",
    "cats_best": "cats_fixed_bestseen_{p}_noid_s{s}",
    "cats_onese": "cats_fixed_onese_{p}_noid_s{s}",
}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", default="ton_iot")
    p.add_argument("--profile", default="laptop")
    p.add_argument("--seeds", type=int, nargs="+", default=[101, 202, 303])
    a = p.parse_args()
    rows = []
    for s in a.seeds:
        for m, pat in FOLDERS.items():
            f = RESULTS_DIR / a.dataset / pat.format(p=a.profile, s=s) / "folds.csv"
            if not f.exists():
                print(f"missing: {f}")
                continue
            d = pd.read_csv(f)
            for _, r in d.iterrows():
                rows.append(dict(seed=s, fold=int(r["fold"]), method=m, f1=r["rf_macro_f1"],
                                 fpr=r["rf_fpr"], n=r["n_selected"]))
                if m == "acats":
                    rows.append(dict(seed=s, fold=int(r["fold"]), method="all_features",
                                     f1=r["all_features_rf_macro_f1"],
                                     fpr=r["all_features_rf_fpr"], n=np.nan))
    df = pd.DataFrame(rows)
    piv = df.pivot_table(index=["seed", "fold"], columns="method", values="f1")
    summ = df.groupby("method").agg(macro_f1=("f1", "mean"), sd=("f1", "std"),
                                    fpr=("fpr", "mean"), n_features=("n", "mean"))
    print(f"\n=== {a.dataset}: {len(piv)} paired folds (seeds {a.seeds}) ===")
    print(summ.round(4).to_string())
    print("\nPaired differences (Macro-F1), Wilcoxon signed-rank:")
    out = []
    for x, y in [("acats", "cats_best"), ("acats", "acats_search"), ("acats", "cats_onese"),
                 ("acats", "all_features"), ("cats_onese", "cats_best")]:
        if x in piv and y in piv:
            d = (piv[x] - piv[y]).dropna()
            pval = wilcoxon(d).pvalue if len(d) > 5 and np.any(d != 0) else float("nan")
            out.append(dict(comparison=f"{x} - {y}", mean_diff=d.mean(), wins=int((d > 0).sum()),
                            losses=int((d < 0).sum()), p_value=pval))
    res = pd.DataFrame(out)
    print(res.round(4).to_string(index=False))
    path = RESULTS_DIR / a.dataset / f"compare_seeds_{a.profile}.csv"
    res.to_csv(path, index=False)
    summ.to_csv(path.with_name(f"compare_seeds_{a.profile}_summary.csv"))
    print(f"\nSaved {path}")


if __name__ == "__main__":
    main()
