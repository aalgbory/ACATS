"""Inspect a dataset file or folder before running anything (e.g. CICIoT2023)."""
from __future__ import annotations

import argparse
import glob
import io
from pathlib import Path

import pandas as pd

IDENTITY_HINTS = {"ts", "src_ip", "dst_ip", "src_port", "dst_port", "saddr", "daddr", "sport",
                  "dport", "stime", "ltime", "pkseqid", "seq", "timestamp", "flow id", "flow_id",
                  "source ip", "destination ip", "source port", "destination port",
                  "ipv4_src_addr", "ipv4_dst_addr", "l4_src_port", "l4_dst_port",
                  "flow_start_milliseconds", "flow_end_milliseconds", "dns_query_id"}
LABEL_HINTS = {"label", "type", "attack", "category", "subcategory", "attack_cat", "class"}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("path")
    p.add_argument("--rows", type=int, default=20000, help="rows to read from the first file")
    a = p.parse_args()
    path = Path(a.path)
    files = [path] if path.is_file() else sorted(
        Path(f) for f in glob.glob(str(path / "**" / "*.csv"), recursive=True))
    buf = io.StringIO()

    def out(s=""):
        print(s)
        buf.write(s + "\n")

    if not files:
        other = sorted(Path(f).suffix.lower() for f in glob.glob(str(path / "**" / "*.*"), recursive=True))
        out(f"No CSV files under {path}. Other extensions: {pd.Series(other).value_counts().to_dict()}")
        return
    total = sum(f.stat().st_size for f in files) / 1e6
    out(f"{len(files)} CSV file(s), {total:.1f} MB in total")
    folders = pd.Series([f.parent.name for f in files]).value_counts()
    if len(folders) > 1:
        out(f"{len(folders)} sub-folders (used as class names when the CSVs have no label column):")
        out(folders.to_string())
    for f in files[:5]:
        out(f"  {f.name}  {f.stat().st_size / 1e6:.1f} MB")
    if len(files) > 5:
        out(f"  ... and {len(files) - 5} more")
    df = pd.read_csv(files[0], nrows=a.rows, low_memory=False, encoding="utf-8-sig")
    df.columns = [str(c).replace("\ufeff", "").strip() for c in df.columns]
    out(f"\nFirst file: {files[0].name}  -> {df.shape[1]} columns ({len(df)} rows read)")
    for c in df.columns:
        out(f"  {c:35s} {str(df[c].dtype):10s} e.g. {str(df[c].iloc[0])[:40]}")
    out("\nIdentity-like columns: " + str([c for c in df.columns if c.lower() in IDENTITY_HINTS]))
    for c in df.columns:
        is_text = not pd.api.types.is_numeric_dtype(df[c])
        if c.lower() in LABEL_HINTS or (is_text and df[c].nunique() <= 60):
            out(f"\nValue counts of '{c}':")
            out(df[c].value_counts().head(40).to_string())
    rep = (path if path.is_dir() else path.parent) / f"inspect_{path.stem}.txt"
    try:
        rep.write_text(buf.getvalue(), encoding="utf-8")
        print(f"\nReport written to {rep}")
    except OSError:
        pass


if __name__ == "__main__":
    main()
