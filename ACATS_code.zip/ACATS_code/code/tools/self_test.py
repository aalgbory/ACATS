"""Fast unit checks of the building blocks (no dataset needed, < 30 s).

    python -m tools.self_test

Checks
  1. CA rules follow the Wolfram encoding (Rule 30 table, Rule 90 = XOR of neighbours)
  2. Nazir Fig. 5 is NOT reproducible with Rule 30 (ring or null boundary)
  3. Nazir cost reproduces Table 4 (4.496 for CAT-S, 4.502 for Dey) and shows that
     the aspiration level 0.02 can never be reached
  4. Metrics recomputed from Nazir's confusion matrix (Fig. 7): Acc 99.50 %, FPR != 0.004
  5. Spectral lattice puts correlated features next to each other
  6. UCB1 learns the best arm
  7. Window neighbours change only cells inside one window
"""
from __future__ import annotations

import numpy as np

from common.metrics import binary_fpr, macro_f1, nazir_cost, weighted_fpr
from framework.bandit import UCB1
from framework.ca_rules import ca_step, window_neighbours
from framework.lattice import adjacent_coherence, discretize, fiedler_order, nmi_matrix

OK, FAIL = "PASS", "FAIL"
results = []


def check(name, cond, detail=""):
    results.append(cond)
    print(f"[{OK if cond else FAIL}] {name}" + (f"  ({detail})" if detail else ""))


def test_rules():
    # Rule 30: 111 110 101 100 011 010 001 000 -> 0 0 0 1 1 1 1 0
    patterns = [(1, 1, 1), (1, 1, 0), (1, 0, 1), (1, 0, 0), (0, 1, 1), (0, 1, 0), (0, 0, 1), (0, 0, 0)]
    out = [int(ca_step(np.array(p, np.uint8), 30, "null")[1]) for p in patterns]
    check("Rule 30 truth table", out == [0, 0, 0, 1, 1, 1, 1, 0], str(out))
    x = np.random.default_rng(0).integers(0, 2, 40).astype(np.uint8)
    check("Rule 90 = left XOR right (ring)",
          np.array_equal(ca_step(x, 90, "ring"), np.roll(x, 1) ^ np.roll(x, -1)))


def test_fig5():
    cur = np.array([1, 0, 1, 1, 1, 1, 0, 1], np.uint8)
    fig = np.array([1, 1, 0, 0, 0, 1, 0, 1], np.uint8)
    ring, null = ca_step(cur, 30, "ring"), ca_step(cur, 30, "null")
    check("Nazir Fig. 5 differs from Rule 30 (paper inconsistency confirmed)",
          not np.array_equal(ring, fig) and not np.array_equal(null, fig),
          f"paper {fig.tolist()} | ring {ring.tolist()} | null {null.tolist()}")


def test_cost():
    cats = nazir_cost(0.9950, 13, 0.004)
    dey = nazir_cost(0.9948, 13, 0.0)
    check("Nazir cost of CAT-S = 4.496 (Table 4)", abs(cats - 4.496) < 1e-3, f"{cats:.4f}")
    check("Nazir cost of Dey = 4.502 (Table 4)", abs(dey - 4.502) < 1e-3, f"{dey:.4f}")
    share = 0.333 * 13 / cats
    best_possible = nazir_cost(1.0, 1, 0.0)
    check("feature count is ~96 % of the cost", 0.95 < share < 0.97, f"{share:.1%}")
    check("aspiration 0.02 unreachable (min cost with 1 feature > 0.02)",
          best_possible > 0.02, f"min cost = {best_possible:.3f}")


def test_fig7():
    names = ["Normal", "Scanning", "DoS", "Injection", "DDoS", "Password", "XSS",
             "Ransomware", "Backdoor", "MITM"]
    M = np.array([
        [299647, 13, 37, 91, 16, 28, 39, 94, 12, 23],
        [7, 19801, 88, 57, 2, 21, 0, 1, 0, 23],
        [52, 45, 19815, 31, 10, 25, 5, 2, 0, 15],
        [66, 53, 27, 19633, 93, 10, 67, 18, 0, 31],
        [71, 0, 8, 63, 19693, 18, 76, 58, 0, 13],
        [94, 23, 25, 13, 5, 19701, 53, 69, 1, 16],
        [92, 1, 5, 71, 83, 40, 19683, 18, 3, 4],
        [61, 0, 0, 0, 0, 0, 53, 19886, 0, 0],
        [12, 0, 1, 0, 0, 0, 1, 0, 19984, 2],
        [49, 23, 16, 23, 7, 9, 11, 2, 1, 902]])
    yt, yp = [], []
    for i in range(10):
        for j in range(10):
            yt += [names[i]] * M[i, j]
            yp += [names[j]] * M[i, j]
    yt, yp = np.array(yt), np.array(yp)
    acc = (yt == yp).mean()
    check("Fig. 7 covers the whole TON_IoT file (461,043 rows)", M.sum() > 461_000, f"{M.sum():,}")
    check("Fig. 7 accuracy = 99.50 % (the 95.5 % in the text is a typo)",
          abs(acc - 0.9950) < 5e-4, f"{acc:.4%}")
    bf, wf = binary_fpr(yt, yp, "Normal"), weighted_fpr(yt, yp)
    check("Fig. 7 does not give FPR = 0.004", abs(bf - 0.004) > 1e-3 and abs(wf - 0.004) > 1e-3,
          f"binary {bf:.4f}, weighted {wf:.4f}")
    print(f"       Macro-F1 from Fig. 7 = {macro_f1(yt, yp):.4f}")


def test_lattice():
    rng = np.random.default_rng(1)
    n, groups = 3000, 4
    cols = []
    for g in range(groups):
        z = rng.normal(size=n)
        cols += [z + rng.normal(0, 0.3, n) for _ in range(4)]
    X = np.column_stack(cols)
    perm = rng.permutation(X.shape[1])
    X = X[:, perm]
    W = nmi_matrix(discretize(X, 16))
    order, _ = fiedler_order(W)
    coh = adjacent_coherence(W, order)
    rnd = np.mean([adjacent_coherence(W, rng.permutation(X.shape[1])) for _ in range(200)])
    check("spectral order groups correlated features", coh > 2 * rnd,
          f"neighbour NMI {coh:.3f} vs random {rnd:.3f}")


def test_sparse_lattice():
    """A sparse feature (99 % zeros) must not become an isolated lattice node."""
    rng = np.random.default_rng(4)
    n = 4000
    flag = (rng.random(n) < 0.01).astype(float)            # rare event
    twin = flag * rng.integers(1, 5, n)                     # carries the same event
    noise = rng.normal(size=n)
    X = np.column_stack([flag, twin, noise])
    Wq = nmi_matrix(discretize(X, 16, "quantile"))
    Wa = nmi_matrix(discretize(X, 16, "adaptive"))
    check("sparse twins: quantile bins lose the link, adaptive keeps it",
          Wq[0, 1] < 1e-6 and Wa[0, 1] > 0.5, f"NMI quantile {Wq[0, 1]:.3f}, adaptive {Wa[0, 1]:.3f}")


def test_attribute_tabu():
    from framework.acats import AttributeTabu
    t = AttributeTabu(10, 3, 9, 2, True, 0.5)
    m1 = np.zeros(10, bool); m1[[1, 2]] = True
    t.add(m1, it=1)
    m2 = np.zeros(10, bool); m2[[2, 5]] = True
    m3 = np.zeros(10, bool); m3[[5, 6, 7]] = True
    check("attribute tabu blocks moves that re-flip recent cells",
          t.is_tabu(m2, 2) and not t.is_tabu(m3, 2) and not t.is_tabu(m2, 5))


def test_bandit():
    rng = np.random.default_rng(2)
    b = UCB1([30, 90, 110, 150], rng=rng)
    p = {30: 0.2, 90: 0.3, 110: 0.8, 150: 0.1}
    for _ in range(500):
        a = b.select()
        b.update(float(rng.random() < p[a]))
    pulls = {k: v["pulls"] for k, v in b.stats().items()}
    check("UCB1 prefers the best rule", max(pulls, key=pulls.get) == "110", str(pulls))


def test_window():
    rng = np.random.default_rng(3)
    z = rng.integers(0, 2, 30).astype(np.uint8)
    nbs, starts = window_neighbours(z, 5, 30, 6, "null", rng)
    ok = True
    for nb, s in zip(nbs, starts):
        changed = np.flatnonzero(nb != z)
        ok &= len(changed) > 0 and changed.min() >= s and changed.max() < s + 6
    check("window neighbours are local and non-trivial", bool(ok), f"starts {starts}")


if __name__ == "__main__":
    for t in (test_rules, test_fig5, test_cost, test_fig7, test_lattice, test_sparse_lattice,
              test_attribute_tabu, test_bandit, test_window):
        t()
    print(f"\n{sum(results)}/{len(results)} checks passed")
