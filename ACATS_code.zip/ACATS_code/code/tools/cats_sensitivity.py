"""Run CAT-S under every reading of the details the paper leaves open, and report the range."""
from __future__ import annotations

import argparse
import itertools

import pandas as pd

from common.config import PROFILES, RANDOM_STATE, RESULTS_DIR
from common.utils import ensure_utf8_stdout, log
from reproduction.cats_pipeline import run

PAPER_ACC = 0.9950


def _m(s: str) -> float:
    return float(str(s).split("±")[0])


def main():
    ensure_utf8_stdout()
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", default="ton_iot")
    p.add_argument("--profile", default="laptop", choices=list(PROFILES))
    p.add_argument("--runs", type=int, default=None)
    p.add_argument("--seed", type=int, default=RANDOM_STATE)
    p.add_argument("--drop-identity", action="store_true")
    a = p.parse_args()

    rows = []
    combos = list(itertools.product(["generations", "perturbed"], ["ring", "null"],
                                    ["solution", "move"]))
    for i, (nb, bd, ts) in enumerate(combos, 1):
        log(f"##### reading {i}/{len(combos)}: neighbours={nb} boundary={bd} tabu={ts}")
        s = run(a.dataset, a.profile, a.runs, a.seed, not a.drop_identity, nb, bd, ts,
                tag=f"_sens_{nb}_{bd}_{ts}")
        rows.append(dict(
            neighbours=nb, boundary=bd, tabu_store=ts, n_selected=s["n_selected"],
            paper_style_accuracy=s["paper_style"]["accuracy"],
            paper_style_fpr=s["paper_style"]["fpr"],
            holdout_accuracy=s["holdout"]["accuracy"],
            holdout_macro_f1=s["holdout"]["macro_f1"],
            best_seen_holdout_accuracy=s["best_seen_holdout"]["accuracy"],
            all_features_paper_style_accuracy=s["all_features_paper_style"]["accuracy"],
            skipped_iterations=s["skipped_iterations"], aspirations=s["aspirations_total"],
            bits_changed_per_move=s["mean_bits_changed_per_move"]))
    df = pd.DataFrame(rows)
    out = RESULTS_DIR / a.dataset / f"cats_sensitivity_{a.profile}" \
        f"{'_noid' if a.drop_identity else '_keepid'}.csv"
    df.to_csv(out, index=False)

    acc = df["paper_style_accuracy"].map(_m)
    best, worst = df.loc[acc.idxmax()], df.loc[acc.idxmin()]
    log("=" * 70)
    log(f"CAT-S paper-style accuracy over 8 readings: {acc.min():.4f} .. {acc.max():.4f} "
        f"(published {PAPER_ACC:.4f})")
    log(f"  best : {best['neighbours']}/{best['boundary']}/{best['tabu_store']}  "
        f"Acc {best['paper_style_accuracy']}  n {best['n_selected']}")
    log(f"  worst: {worst['neighbours']}/{worst['boundary']}/{worst['tabu_store']}  "
        f"Acc {worst['paper_style_accuracy']}  n {worst['n_selected']}")
    log(f"  RF on all features, same protocol: {df['all_features_paper_style_accuracy'].iloc[0]}")
    verdict = "below" if acc.max() < PAPER_ACC else "reaches"
    log(f"  even the most favourable reading {verdict} the published 99.50 %")
    log(f"Table written to {out}")


if __name__ == "__main__":
    main()
