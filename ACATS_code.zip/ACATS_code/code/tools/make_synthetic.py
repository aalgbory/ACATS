"""Generate a small synthetic IoT-like dataset for testing the pipeline."""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd
from sklearn.datasets import make_classification

from common.config import DATA_DIR


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--rows", type=int, default=20000)
    p.add_argument("--seed", type=int, default=7)
    a = p.parse_args()
    rng = np.random.default_rng(a.seed)

    classes = ["normal", "scanning", "dos", "injection", "ddos", "password", "xss",
               "ransomware", "backdoor", "mitm"]
    weights = np.array([0.62, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.04, 0.035, 0.005])
    X, y = make_classification(n_samples=a.rows, n_features=14, n_informative=8,
                               n_redundant=4, n_repeated=0, n_classes=len(classes),
                               n_clusters_per_class=2, weights=list(weights / weights.sum()),
                               class_sep=2.0, flip_y=0.005, random_state=a.seed)
    cols = {}
    for j in range(X.shape[1]):
        cols[f"f{j:02d}"] = X[:, j]
        for c in range(2):
            cols[f"f{j:02d}_v{c}"] = X[:, j] * rng.uniform(0.5, 2) + rng.normal(0, 0.3, len(y))
    for j in range(6):
        cols[f"noise{j}"] = rng.normal(size=len(y))
    df = pd.DataFrame(cols)
    df = df[rng.permutation(df.columns)]

    lab = np.array(classes)[y]
    df["proto"] = rng.choice(["tcp", "udp", "icmp"], size=len(y))
    svc = rng.choice(["http", "dns", "ssl", "-"], size=len(y), p=[0.3, 0.3, 0.2, 0.2])
    df["service"] = svc
    attacker_ip = {c: f"192.168.1.{10 + i}" for i, c in enumerate(classes)}
    df["src_ip"] = [attacker_ip[c] if (c != "normal" and rng.random() < 0.9)
                    else f"10.0.{rng.integers(255)}.{rng.integers(255)}" for c in lab]
    df["dst_ip"] = [f"10.0.0.{rng.integers(1, 50)}" for _ in lab]
    df["src_port"] = rng.integers(1024, 65535, size=len(y))
    df["dst_port"] = np.where(lab == "normal", rng.choice([80, 443, 53], size=len(y)),
                              rng.integers(1, 1024, size=len(y)))
    df["ts"] = 1_550_000_000 + y * 10_000 + rng.integers(0, 5000, size=len(y))
    df["attack_cat"] = lab
    df["is_attack"] = (lab != "normal").astype(int)

    out = DATA_DIR / "synthetic" / "synthetic.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(f"Wrote {out}  ({len(df)} rows, {df.shape[1]} columns)")
    print(pd.Series(lab).value_counts().to_string())


if __name__ == "__main__":
    main()
