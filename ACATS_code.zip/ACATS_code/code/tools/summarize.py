"""Collect every summary.json under results/ into one comparison table."""
from __future__ import annotations

import argparse
import json

import pandas as pd

from common.config import RESULTS_DIR


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", default=None)
    a = p.parse_args()
    rows = []
    for f in sorted(RESULTS_DIR.glob("*/*/summary.json")):
        s = json.loads(f.read_text(encoding="utf-8"))
        if a.dataset and s.get("dataset") != a.dataset:
            continue
        base = dict(dataset=s.get("dataset"), method=s.get("method"), profile=s.get("profile"),
                    identity=s.get("identity"), n_selected=s.get("n_selected"),
                    search_seconds=s.get("search_seconds"), folder=f.parent.name)
        if "models" in s:
            for m, d in s["models"].items():
                rows.append({**base, "final_model": m, "protocol": "nested CV",
                             "macro_f1": d["macro_f1"], "fpr": d["fpr"],
                             "accuracy": d["accuracy"], "pooled_macro_f1": d["pooled_macro_f1"]})
        else:
            for proto in ("paper_style", "holdout", "best_seen_holdout"):
                d = s[proto]
                rows.append({**base, "final_model": "rf", "protocol": proto,
                             "macro_f1": d["macro_f1"], "fpr": d["fpr"],
                             "accuracy": d["accuracy"], "pooled_macro_f1": ""})
    if not rows:
        print("No results yet.")
        return
    df = pd.DataFrame(rows)
    out = RESULTS_DIR / "comparison.csv"
    df.to_csv(out, index=False, encoding="utf-8-sig")
    with pd.option_context("display.width", 200, "display.max_columns", 20):
        print(df.drop(columns=["folder"]).to_string(index=False))
    print(f"\nSaved {out}")


if __name__ == "__main__":
    main()
