"""Baseline: Sarhan et al. [52] - Extra Trees on all features (no feature selection),
re-run on the same nested folds as ACATS.

    python -m baselines.sarhan_et --dataset ton_iot --profile laptop
"""
from __future__ import annotations

import argparse

import numpy as np
from sklearn.ensemble import ExtraTreesClassifier

from common.config import PROFILES, RANDOM_STATE
from common.nested import run_nested
from common.utils import ensure_utf8_stdout


def main():
    ensure_utf8_stdout()
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", default="synthetic")
    p.add_argument("--profile", default="quick", choices=list(PROFILES))
    p.add_argument("--seed", type=int, default=RANDOM_STATE)
    a = p.parse_args()
    prof = PROFILES[a.profile]

    def et():
        return ExtraTreesClassifier(n_estimators=prof["trees_final"], n_jobs=-1,
                                    random_state=a.seed)

    def search_fn(Xs, ys, ctx):              # no selection: every feature
        return dict(mask=np.ones(Xs.shape[1], dtype=bool), info={})

    run_nested(a.dataset, a.profile, "sarhan_extratrees", search_fn,
               final_models={"extratrees": (et, None)}, seed=a.seed,
               reference_all_features=True)


if __name__ == "__main__":
    main()
