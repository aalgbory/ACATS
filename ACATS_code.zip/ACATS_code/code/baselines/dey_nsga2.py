"""Baseline re-implementation of Dey et al. [50] "Filter + NSGA-II" with an SVM,
run on the SAME nested folds as ACATS (instead of copying their reported number).

Our reading (their paper is not fully specified in Nazir's table):
  * filter : rank features by mutual information with the label (outer-train search sample
             only) and keep the top 50 %
  * NSGA-II: binary chromosome over the kept features, objectives
             (1 - Macro-F1 of an RBF-SVM on inner folds, number of features),
             binary tournament, uniform crossover (p=0.9), bit-flip mutation (1/L)
  * pick   : from the first Pareto front, the solution with the lowest ACATS fitness
  * final  : RBF-SVM (as Dey) and RF (same final model as ACATS, for a fair comparison)

    python -m baselines.dey_nsga2 --dataset ton_iot --profile laptop
"""
from __future__ import annotations

import argparse

import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from common.config import ACATS, PROFILES, RANDOM_STATE
from common.data import stratified_cap
from common.evaluator import FitnessEvaluator, rf_factory
from common.nested import make_inner_splits, run_nested
from common.utils import ensure_utf8_stdout, log
from framework.lattice import discretize, mi_with_target


def svm_factory(seed):
    def make():
        return make_pipeline(StandardScaler(), SVC(kernel="rbf", C=1.0, gamma="scale",
                                                   random_state=seed))
    return make


# ----------------------------------------------------------------------------- NSGA-II
def non_dominated_sort(F: np.ndarray) -> list[list[int]]:
    n = len(F)
    S = [[] for _ in range(n)]
    cnt = np.zeros(n, dtype=int)
    fronts = [[]]
    for p in range(n):
        for q in range(n):
            if p == q:
                continue
            if np.all(F[p] <= F[q]) and np.any(F[p] < F[q]):
                S[p].append(q)
            elif np.all(F[q] <= F[p]) and np.any(F[q] < F[p]):
                cnt[p] += 1
        if cnt[p] == 0:
            fronts[0].append(p)
    i = 0
    while fronts[i]:
        nxt = []
        for p in fronts[i]:
            for q in S[p]:
                cnt[q] -= 1
                if cnt[q] == 0:
                    nxt.append(q)
        i += 1
        fronts.append(nxt)
    return fronts[:-1]


def crowding(F: np.ndarray, front: list[int]) -> np.ndarray:
    d = np.zeros(len(front))
    if len(front) <= 2:
        return np.full(len(front), np.inf)
    sub = F[front]
    for m in range(F.shape[1]):
        o = np.argsort(sub[:, m])
        d[o[0]] = d[o[-1]] = np.inf
        rng_ = sub[o[-1], m] - sub[o[0], m] or 1.0
        d[o[1:-1]] += (sub[o[2:], m] - sub[o[:-2], m]) / rng_
    return d


def nsga2(evaluate, L: int, pop: int, gens: int, rng: np.random.Generator):
    P = (rng.random((pop, L)) < 0.5).astype(np.uint8)
    P[P.sum(1) == 0, rng.integers(L)] = 1

    def objs(pop_):
        out = []
        for ind in pop_:
            _, info = evaluate(ind.astype(bool))
            out.append((1 - info.get("macro_f1", 0.0), ind.sum()))
        return np.array(out, dtype=float)

    F = objs(P)
    history = []
    for g in range(gens):
        fronts = non_dominated_sort(F)
        rank = np.empty(len(P), dtype=int)
        crowd = np.empty(len(P))
        for r, fr in enumerate(fronts):
            rank[fr] = r
            crowd[fr] = crowding(F, fr)

        def tourney():
            a, b = rng.integers(len(P), size=2)
            if rank[a] != rank[b]:
                return a if rank[a] < rank[b] else b
            return a if crowd[a] > crowd[b] else b

        kids = []
        while len(kids) < pop:
            p1, p2 = P[tourney()], P[tourney()]
            if rng.random() < 0.9:
                m = rng.random(L) < 0.5
                c1, c2 = np.where(m, p1, p2), np.where(m, p2, p1)
            else:
                c1, c2 = p1.copy(), p2.copy()
            for c in (c1, c2):
                flip = rng.random(L) < 1.0 / L
                c[flip] ^= 1
                if c.sum() == 0:
                    c[rng.integers(L)] = 1
                kids.append(c)
        Q = np.array(kids[:pop], dtype=np.uint8)
        R = np.vstack([P, Q])
        FR = np.vstack([F, objs(Q)])
        newP = []
        for fr in non_dominated_sort(FR):
            if len(newP) + len(fr) <= pop:
                newP.extend(fr)
            else:
                cd = crowding(FR, fr)
                newP.extend(np.array(fr)[np.argsort(-cd)][:pop - len(newP)])
                break
        P, F = R[newP], FR[newP]
        history.append(dict(iteration=g + 1, best_f=float(F[:, 0].min()),
                            front_size=len(non_dominated_sort(F)[0])))
    front = non_dominated_sort(F)[0]
    return P[front], F[front], history


# ----------------------------------------------------------------------------- driver
def make_search_fn():
    def search_fn(Xs, ys, ctx):
        prof, rng = ctx["profile"], ctx["rng"]
        D = Xs.shape[1]
        mi = mi_with_target(discretize(Xs, ACATS["mi_bins"]), ys)
        kept = np.sort(np.argsort(-mi)[:max(2, int(np.ceil(D / 2)))])
        n_cls = len(np.unique(ys))
        sub = stratified_cap(ys, prof["svm_search_rows"],
                             max(10, prof["svm_search_rows"] // (3 * n_cls)), rng)
        Xv, yv = Xs[np.ix_(sub, kept)], ys[sub]
        splits = make_inner_splits(yv, prof["inner_folds"], ctx["seed"])
        ev = FitnessEvaluator(Xv, yv, ctx["normal"], splits, svm_factory(ctx["seed"]),
                              kind="normalized", weights=ACATS["weights"])
        log(f"  filter kept {len(kept)}/{D} features; NSGA-II on {len(sub)} rows")
        front, F, hist = nsga2(ev, len(kept), prof["nsga_pop"], prof["nsga_gens"], rng)
        fit = [ev(ind.astype(bool))[0] for ind in front]
        best = front[int(np.argmin(fit))].astype(bool)
        mask = np.zeros(D, dtype=bool)
        mask[kept[best]] = True
        info = dict(filter_kept=len(kept), pareto_size=len(front), **ev.stats())
        return dict(mask=mask, history=hist, info=info)
    return search_fn


def main():
    ensure_utf8_stdout()
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", default="synthetic")
    p.add_argument("--profile", default="quick", choices=list(PROFILES))
    p.add_argument("--seed", type=int, default=RANDOM_STATE)
    a = p.parse_args()
    prof = PROFILES[a.profile]
    finals = {"svm": (svm_factory(a.seed), prof["svm_final_rows"]),
              "rf": (rf_factory(prof["trees_final"], a.seed), None)}
    run_nested(a.dataset, a.profile, "dey_filter_nsga2", make_search_fn(), final_models=finals,
               seed=a.seed, extra_meta=dict(filter="top 50% MI", objectives="1-MacroF1, |S|"))


if __name__ == "__main__":
    main()
