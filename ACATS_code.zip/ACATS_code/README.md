# ACATS: Noise-Aware Cellular Automata–Tabu Search for Feature Selection in IoT Intrusion Detection

Source code for the experiments of the manuscript. It contains the proposed ACATS framework,
a re-implementation of CAT-S, the leakage-free evaluation protocol and the analysis tools.

## Requirements

Python 3.10 or later.

```
pip install -r requirements.txt
```

## Folder layout

```
ACATS_code/
  code/
    common/        configuration, data loading, metrics, nested cross-validation, cached fitness
    framework/     ACATS: lattice, cellular automata rules, UCB1 bandit, tabu search, final selection, ablation
    reproduction/  CAT-S as published and CAT-S with the corrected evaluation
    baselines/     additional wrapper baselines
    tools/         self-test, dataset inspection, sensitivity analysis, paired comparison over seeds
  data/            datasets (not included, see below)
  results/         created automatically
  run_experiments.bat
  requirements.txt
```

## Data

The datasets are public and are not redistributed here. Place them as follows:

| Dataset | Location |
|---|---|
| TON_IoT network data | `data/ton_iot/train_test_network.csv` |
| CICIoT2023 (per-capture CSV release) | `data/ciciot2023/<attack folder>/*.csv` |

For CICIoT2023 the class of each record is taken from the name of its folder, and the 34 attack
types are grouped into eight families. Check that a dataset is read correctly with:

```
cd code
python -m tools.inspect_dataset ../data/ton_iot/train_test_network.csv
```

## Quick check

```
cd code
python -m tools.self_test
```

All checks run on synthetic data and should pass.

## Reproducing the experiments

All commands are run from the `code` folder. ACATS and the corrected CAT-S remove identity
features (IP addresses, ports and timestamps) by default; the CAT-S reproduction keeps them unless
`--drop-identity` is given, as in the original paper.

Re-examination of CAT-S under its own setting (eight readings of the unspecified details):

```
python -m tools.cats_sensitivity --dataset ton_iot --profile paper
```

CAT-S as published, with and without identity features:

```
python -m reproduction.cats_pipeline --dataset ton_iot --profile laptop
python -m reproduction.cats_pipeline --dataset ton_iot --profile laptop --drop-identity
```

ACATS (proposed setting):

```
python -m framework.run_acats --dataset ton_iot --profile laptop --seed 101
```

Comparison on fresh seeds (ACATS, ACATS search only, CAT-S with corrected evaluation,
CAT-S with the ACATS final selection) followed by paired Wilcoxon tests:

```
..\run_experiments.bat
```

or for one dataset:

```
python -m framework.run_acats --dataset ton_iot --profile laptop --seed 101
python -m framework.run_acats --dataset ton_iot --profile laptop --seed 101 --final best --sizew 0.10
python -m reproduction.cats_fixed --dataset ton_iot --profile laptop --seed 101 --output best
python -m reproduction.cats_fixed --dataset ton_iot --profile laptop --seed 101 --output onese
python -m tools.compare_seeds --dataset ton_iot --profile laptop --seeds 101 202 303
```

Ablation of the search components:

```
python -m framework.ablation --dataset ton_iot --profile laptop --seed 42
```

## Profiles

| Profile | Use |
|---|---|
| `quick` | smoke test on a small sample |
| `laptop` | experiments of the manuscript (60,000-record stratified sample, 3 outer folds) |
| `full` | all records |
| `paper` | setting closest to the original CAT-S paper (all records, 100 iterations, 500 trees) |

Each run writes `summary.json`, `folds.csv`, `per_class_f1.csv` and the search history to
`results/<dataset>/<run name>/`.
